import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from tax import TaxPlanner

class TaxPlanningUI:
    def __init__(self):
        self.tax_planner = TaxPlanner()
        
    def render_tax_planning_section(self, all_funds_df):
        st.title("Tax Planning")
        st.write("Optimize your investments for tax efficiency")
        
        # Create tabs for different tax planning features
        tabs = st.tabs([
            "Capital Gains Calculator", 
            "ELSS Recommendations"
        ])
        
        # Tab 1: Capital Gains Calculator
        with tabs[0]:
            self.render_capital_gains_calculator()
            
        # Tab 2: ELSS Recommendations
        with tabs[1]:
            self.render_elss_recommendations(all_funds_df)
    
    def render_capital_gains_calculator(self):
        st.subheader("Capital Gains Calculator")
        st.write("Calculate potential capital gains tax on your investments")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Investment Details")
            asset_type = st.selectbox(
                "Asset Type", 
                ["EQUITY", "DEBT"],
                help="Equity includes stocks and equity mutual funds. Debt includes debt mutual funds, bonds, etc."
            )
            
            purchase_price = st.number_input(
                "Purchase Price (₹)", 
                min_value=0.01, 
                value=100.0,
                step=0.01,
                help="NAV or share price at the time of purchase"
            )
            
            current_price = st.number_input(
                "Current Price (₹)", 
                min_value=0.01, 
                value=150.0,
                step=0.01,
                help="Current NAV or share price"
            )
            
            units = st.number_input(
                "Number of Units/Shares", 
                min_value=0.01, 
                value=100.0,
                step=0.01,
                help="Number of units or shares held"
            )
            
            purchase_date = st.date_input(
                "Purchase Date", 
                value=datetime.now() - timedelta(days=366),
                help="Date of purchase or allotment"
            )
            
            # Add income and tax bracket for debt fund taxation
            if asset_type == "DEBT":
                st.markdown("#### Income Details")
                annual_income = st.number_input(
                    "Annual Income (₹)",
                    min_value=0.0,
                    value=1000000.0,
                    step=10000.0,
                    help="Your total annual income for tax calculation purposes"
                )
                
                tax_brackets = {
                    "₹0 - ₹3,00,000 - 0%": 0.0,
                    "₹3,00,001 - ₹6,00,000 - 5%": 0.05,
                    "₹6,00,001 - ₹9,00,000 - 10%": 0.10,
                    "₹9,00,001 - ₹12,00,000 - 15%": 0.15,
                    "₹12,00,001 - ₹15,00,000 - 20%": 0.20,
                    "Above ₹15,00,000 - 30%": 0.30
                }
                
                selected_bracket = st.selectbox(
                    "Income Tax Bracket",
                    options=list(tax_brackets.keys()),
                    index=5,  # Default to highest bracket (30%)
                    help="Select your income tax bracket for debt fund taxation"
                )
                income_tax_rate = tax_brackets[selected_bracket]
            
        with col2:
            st.markdown("#### Tax Information")
            st.markdown("""
            **Equity Investments:**
            - Short Term Capital Gains (STCG): Held for ≤ 1 year, taxed at 15%
            - Long Term Capital Gains (LTCG): Held for > 1 year, taxed at 10% (exemption up to ₹1 lakh)
            
            **Non-Equity Investments (Debt/Gold/International Funds):**
            - All capital gains (both short and long term) are now added to your income and taxed as per your income tax slab rate
            """)
            
            calculate_button = st.button("Calculate Capital Gains")
            
            if calculate_button:
                # Convert date input to string format expected by the function
                purchase_date_str = purchase_date.strftime('%Y-%m-%d')
                
                # Calculate capital gains
                if asset_type == "DEBT":
                    # Include income tax rate for debt calculations
                    result = self.tax_planner.calculate_capital_gains(
                        purchase_price, 
                        current_price, 
                        units, 
                        purchase_date_str, 
                        asset_type,
                        income_tax_rate=income_tax_rate
                    )
                else:
                    # For equity, use default calculations
                    result = self.tax_planner.calculate_capital_gains(
                        purchase_price, 
                        current_price, 
                        units, 
                        purchase_date_str, 
                        asset_type
                    )
                
                # Display results
                st.success("Calculation Complete!")
                
                # Create a nice card-like display for the results
                st.markdown("""
                <style>
                .result-card {
                    background-color: #f0f2f6;
                    border-radius: 10px;
                    padding: 20px;
                    margin-top: 20px;
                }
                </style>
                """, unsafe_allow_html=True)
                
                st.markdown("<div class='result-card'>", unsafe_allow_html=True)
                
                st.markdown(f"##### Investment Summary")
                st.markdown(f"Total Investment: ₹{purchase_price * units:,.2f}")
                st.markdown(f"Current Value: ₹{current_price * units:,.2f}")
                
                # Determine if profit or loss
                if result['capital_gains'] > 0:
                    st.markdown(f"Total Gain: ₹{result['capital_gains']:,.2f} (Profit)")
                else:
                    st.markdown(f"Total Loss: ₹{abs(result['capital_gains']):,.2f} (Loss)")
                
                st.markdown(f"Holding Period: {result['holding_period_days']} days")
                st.markdown(f"Gain Type: {result['gain_type']}")
                
                if result['tax_liability'] > 0:
                    st.markdown(f"Estimated Tax Liability: ₹{result['tax_liability']:,.2f}")
                else:
                    st.markdown("Estimated Tax Liability: ₹0.00 (No tax applicable)")
                
                st.markdown("</div>", unsafe_allow_html=True)
                
                # Add a visualization
                fig = go.Figure()
                
                # Data for the chart
                labels = ['Initial Investment', 'Capital Gain', 'Tax']
                values = [
                    purchase_price * units, 
                    max(0, result['capital_gains']), 
                    result['tax_liability']
                ]
                
                # Create a pie chart for the breakdown
                fig = px.pie(
                    values=values,
                    names=labels,
                    title="Investment Breakdown",
                    color_discrete_sequence=px.colors.sequential.Bluyl
                )
                
                st.plotly_chart(fig)
    
    def render_elss_recommendations(self, all_funds_df):
        st.subheader("ELSS Fund Recommendations")
        st.write("Tax-saving mutual funds under Section 80C with a 3-year lock-in period")
        
        # Get user risk profile
        risk_profile = st.selectbox(
            "Your Risk Tolerance",
            ["Conservative", "Moderate", "Aggressive"],
            index=1,  # Default to Moderate
            help="Conservative: Lower risk, lower returns. Moderate: Balanced approach. Aggressive: Higher risk, potentially higher returns."
        )
        
        num_recommendations = st.slider(
            "Number of Recommendations",
            min_value=3,
            max_value=10,
            value=5,
            help="How many ELSS funds you want to see"
        )
        
        get_recommendations = st.button("Get ELSS Recommendations")
        
        if get_recommendations:
            recommendations = self.tax_planner.get_elss_recommendations(
                all_funds_df, 
                risk_profile=risk_profile, 
                top_n=num_recommendations
            )
            
            if recommendations.empty:
                st.warning("No ELSS funds found in the database. Please check the data source.")
            else:
                st.success(f"Found {len(recommendations)} ELSS funds matching your risk profile")
                
                # Display the recommendations in a table
                display_cols = [
                    'scheme_name', 'amc_name', 'expense_ratio', 
                    'returns_1yr', 'returns_3yr', 'returns_5yr', 
                    'sharpe', 'min_sip', 'final_score'
                ]
                
                formatted_df = recommendations[display_cols].copy()
                formatted_df.columns = [
                    'Scheme Name', 'AMC', 'Expense Ratio (%)', 
                    '1Y Return (%)', '3Y Return (%)', '5Y Return (%)', 
                    'Sharpe Ratio', 'Min SIP (₹)', 'Score'
                ]
                
                # Round numeric columns
                numeric_cols = ['Expense Ratio (%)', '1Y Return (%)', '3Y Return (%)', 
                                '5Y Return (%)', 'Sharpe Ratio', 'Score']
                for col in numeric_cols:
                    if col in formatted_df.columns:
                        formatted_df[col] = formatted_df[col].round(2)
                
                # Sort by score descending
                formatted_df = formatted_df.sort_values('Score', ascending=False)
                
                # Display as a styled dataframe
                st.dataframe(formatted_df, use_container_width=True)
                
                # Create a bar chart for returns comparison
                st.subheader("Returns Comparison")
                
                fig = go.Figure()
                
                for fund in recommendations['scheme_name'].head(5):
                    fund_data = recommendations[recommendations['scheme_name'] == fund]
                    
                    # Get return values, handling missing values
                    returns = []
                    for period in ['returns_1yr', 'returns_3yr', 'returns_5yr']:
                        if period in fund_data.columns and not pd.isna(fund_data[period].values[0]):
                            returns.append(fund_data[period].values[0])
                        else:
                            returns.append(0)
                    
                    fig.add_trace(go.Bar(
                        x=['1 Year', '3 Years', '5 Years'],
                        y=returns,
                        name=fund[:30] + '...' if len(fund) > 30 else fund
                    ))
                
                fig.update_layout(
                    title="Returns Comparison (%)",
                    xaxis_title="Time Period",
                    yaxis_title="Returns (%)",
                    barmode='group',
                    height=500
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Add tax-saving information
                st.info("""
                **ELSS Tax Benefits:**
                - Investments up to ₹1.5 lakhs per financial year qualify for tax deduction under Section 80C
                - Lock-in period of 3 years (shortest among tax-saving instruments)
                - Returns are taxed as long-term capital gains (10% tax on gains above ₹1 lakh)
                """)