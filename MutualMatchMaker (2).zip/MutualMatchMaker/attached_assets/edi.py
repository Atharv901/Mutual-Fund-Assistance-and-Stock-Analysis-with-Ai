import streamlit as st
import yfinance as yf
import requests
from bs4 import BeautifulSoup
import pandas as pd
import mftool
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
from langchain_anthropic import ChatAnthropic
from langchain.prompts import PromptTemplate

# Configure page
st.set_page_config(page_title="Investment Analysis Platform", layout="wide")

# Initialize session state variables
if 'page' not in st.session_state:
    st.session_state.page = 'home'
if 'user_profile' not in st.session_state:
    st.session_state.user_profile = {
        'age': 30,
        'marital_status': 'Single',
        'income': 1000000,
        'expenses': 600000,
        'time_horizon': 'Medium-term (3-7 years)',
        'risk_aversion': 'Moderate',
        'dependents': 0,
        'health_status': 'Good',
        'financial_goals': 'Saving for retirement and a home purchase'
    }
if 'analysis_results' not in st.session_state:
    st.session_state.analysis_results = None
if 'formatted_data' not in st.session_state:
    st.session_state.formatted_data = None

# Navigation functions
def navigate_to(page):
    st.session_state.page = page

# ------ STOCK ANALYSIS FUNCTIONALITY ------
class StockAnalyzer:
    def __init__(self, stock_symbol):
        """Initialize the stock analyzer with a stock symbol"""
        self.stock_symbol = stock_symbol
        self.yf_symbol = stock_symbol + ".NS"  # Adding .NS for Yahoo Finance
        self.yf_stock = yf.Ticker(self.yf_symbol)

    def get_yahoo_data(self, period="1y"):
        """Fetch data from Yahoo Finance"""
        try:
            historical_data = self.yf_stock.history(period=period)
            historical_data['MA50'] = historical_data['Close'].rolling(window=50).mean()
            historical_data['MA200'] = historical_data['Close'].rolling(window=200).mean()
            financials = self.yf_stock.financials

            return {
                "historical_data": historical_data,
                "financials": financials
            }
        except Exception as e:
            st.error(f"Error fetching Yahoo Finance data: {e}")
            return None

    def get_screener_data(self):
        """Fetch data from Screener.in"""
        url = f"https://www.screener.in/company/{self.stock_symbol}/consolidated/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')
            company_name = soup.find('h1').text.strip()

            key_metrics = {}
            for row in soup.select('#top-ratios li'):
                key = row.find('span', class_='name').text.strip()
                value = row.find('span', class_='number').text.strip()
                key_metrics[key] = value

            tables = soup.find_all('table')
            table_data = {}

            for i, table in enumerate(tables):
                table_name = f"Table_{i + 1}"
                if table.find_previous('h2'):
                    table_name = table.find_previous('h2').text.strip()

                headers = [th.text.strip() for th in table.find_all('th')]
                rows = []

                for tr in table.find_all('tr'):
                    cells = tr.find_all('td')
                    if cells:
                        row = [cell.text.strip() for cell in cells]
                        if len(row) == len(headers):
                            rows.append(row)

                if headers and rows:
                    table_data[table_name] = pd.DataFrame(rows, columns=headers)

            return {
                "Company Name": company_name,
                "Key Metrics": key_metrics,
                "Tables": table_data
            }

        except requests.exceptions.RequestException as e:
            st.error(f"Error fetching Screener.in data: {e}")
            return None

    def analyze(self):
        """Perform complete analysis using both data sources"""
        yahoo_data = self.get_yahoo_data()
        screener_data = self.get_screener_data()

        return {
            "yahoo_finance_data": yahoo_data,
            "screener_data": screener_data
        }

def plot_stock_chart(historical_data):
    """Create a plotly chart for stock price and moving averages"""
    fig = go.Figure()

    # Add candlestick chart
    fig.add_trace(go.Candlestick(
        x=historical_data.index,
        open=historical_data['Open'],
        high=historical_data['High'],
        low=historical_data['Low'],
        close=historical_data['Close'],
        name='Price'
    ))

    # Add moving averages
    fig.add_trace(go.Scatter(
        x=historical_data.index,
        y=historical_data['MA50'],
        name='50-Day MA',
        line=dict(color='blue', width=1.5)
    ))

    fig.add_trace(go.Scatter(
        x=historical_data.index,
        y=historical_data['MA200'],
        name='200-Day MA',
        line=dict(color='red', width=1.5)
    ))

    fig.update_layout(
        title='Stock Price with Moving Averages',
        xaxis_title='Date',
        yaxis_title='Price (₹)',
        height=600,
        xaxis_rangeslider_visible=False
    )

    return fig

def format_data_for_llm(analysis_results):
    """Format the analysis results for LLM consumption"""
    formatted_data = ""

    yf_data = analysis_results.get("yahoo_finance_data")
    if yf_data:
        formatted_data += "\nYahoo Finance Data:\n"
        formatted_data += str(yf_data["historical_data"].tail())
        formatted_data += "\n\nFinancials:\n"
        formatted_data += str(yf_data["financials"])

    screener_data = analysis_results.get("screener_data")
    if screener_data:
        formatted_data += "\n\nScreener.in Data:\n"
        formatted_data += f"\nCompany Name: {screener_data['Company Name']}\n"
        formatted_data += "\nKey Metrics:\n"
        for key, value in screener_data["Key Metrics"].items():
            formatted_data += f"{key}: {value}\n"

    return formatted_data

def format_user_profile(profile):
    """Format user financial profile for LLM query"""
    return f"""
    Age: {profile['age']}
    Marital Status: {profile['marital_status']}
    Annual Income: ₹{profile['income']}
    Annual Expenses: ₹{profile['expenses']}
    Investment Time Horizon: {profile['time_horizon']}
    Risk Appetite: {profile['risk_aversion']}
    Number of Dependents: {profile['dependents']}
    Health Status: {profile['health_status']}
    Financial Goals: {profile['financial_goals']}
    """

# ------ MUTUAL FUND FUNCTIONALITY ------
class MutualFundAnalyzer:
    def __init__(self):
        self.mf = mftool.Mftool()

    def get_all_categories(self):
        """Get all mutual fund categories"""
        try:
            schemes = self.mf.get_scheme_codes()
            categories = set()

            # Extract categories from scheme names
            for code, name in schemes.items():
                parts = name.split('-')
                if len(parts) > 1:
                    category = parts[0].strip()
                    categories.add(category)

            return sorted(list(categories))
        except Exception as e:
            st.error(f"Error fetching mutual fund categories: {e}")
            return []

    def get_schemes_by_category(self, category):
        """Get schemes filtered by category"""
        try:
            all_schemes = self.mf.get_scheme_codes()
            filtered_schemes = {code: name for code, name in all_schemes.items() if name.startswith(category)}
            return filtered_schemes
        except Exception as e:
            st.error(f"Error fetching schemes: {e}")
            return {}

    def get_scheme_details(self, scheme_code):
        """Get detailed information about a specific scheme"""
        try:
            details = self.mf.get_scheme_details(scheme_code)
            nav_history = self.mf.get_scheme_historical_nav(scheme_code)

            return {
                "details": details,
                "nav_history": nav_history
            }
        except Exception as e:
            st.error(f"Error fetching scheme details: {e}")
            return None

def plot_nav_history(nav_data):
    """Create a plotly chart for NAV history"""
    if not nav_data or 'data' not in nav_data:
        return None

    # Convert data to DataFrame
    df = pd.DataFrame(nav_data['data'])

    if df.empty:
        return None

    # Convert date and nav to proper types
    df['date'] = pd.to_datetime(df['date'], format='%d-%m-%Y')
    df['nav'] = pd.to_numeric(df['nav'])

    # Sort by date
    df = df.sort_values('date')

    # Create plot
    fig = px.line(df, x='date', y='nav', title='NAV History')
    fig.update_layout(
        xaxis_title='Date',
        yaxis_title='NAV (₹)',
        height=400
    )

    return fig

# ------ HOME PAGE ------
def home_page():
    st.title("Investment Analysis Platform")
    st.write("Welcome to your comprehensive investment analysis tool. Choose an option below:")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.button("Analyze Stocks", on_click=navigate_to, args=('stocks',), use_container_width=True)
        st.write("Research and analyze Indian stocks based on your financial profile.")

    with col2:
        st.button("View Profile", on_click=navigate_to, args=('profile',), use_container_width=True)
        st.write("Update your financial profile to get personalized investment recommendations.")

    with col3:
        st.button("See Available Mutual Funds", on_click=navigate_to, args=('mutual_funds',), use_container_width=True)
        st.write("Explore and analyze mutual funds available in the Indian market.")

# ------ STOCK ANALYSIS PAGE ------
# def stock_analysis_page():
#     st.title("Stock Analysis")
#
#     # Add back button
#     if st.button("← Back to Home"):
#         navigate_to('home')
#
#     # Stock input
#     stock_symbol = st.text_input("Enter Stock Symbol (e.g., RELIANCE, INFY, TCS)")
#
#     # Show user profile summary
#     st.sidebar.header("Your Investment Profile")
#     for key, value in st.session_state.user_profile.items():
#         st.sidebar.write(f"**{key.replace('_', ' ').title()}:** {value}")
#
#     if st.sidebar.button("Edit Profile"):
#         navigate_to('profile')
#
#     if st.button("Analyze Stock") and stock_symbol:
#         try:
#             with st.spinner("Fetching and analyzing stock data..."):
#                 analyzer = StockAnalyzer(stock_symbol)
#                 st.session_state.analysis_results = analyzer.analyze()
#                 st.session_state.formatted_data = format_data_for_llm(st.session_state.analysis_results)
#         except Exception as e:
#             st.error(f"An error occurred: {str(e)}")
#
#     if st.session_state.analysis_results:
#         # Display company name
#         screener_data = st.session_state.analysis_results.get("screener_data")
#         if screener_data:
#             st.header(screener_data.get("Company Name", stock_symbol))
#
#         # Plot stock chart
#         yahoo_data = st.session_state.analysis_results.get("yahoo_finance_data")
#         if yahoo_data and "historical_data" in yahoo_data:
#             st.plotly_chart(plot_stock_chart(yahoo_data["historical_data"]))
#
#         # Display key metrics
#         if screener_data and "Key Metrics" in screener_data:
#             st.subheader("Key Metrics")
#             metrics_df = pd.DataFrame(list(screener_data["Key Metrics"].items()), columns=["Metric", "Value"])
#             st.dataframe(metrics_df)
#
#         # Investment Suitability Analysis
#         st.header("Investment Suitability Analysis")
#         user_profile = format_user_profile(st.session_state.user_profile)
#
#         api_key =  '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'
#         llm = ChatAnthropic(anthropic_api_key=api_key, model="claude-3-sonnet-20240229")
#
#         suitability_template = PromptTemplate(
#             input_variables=["stock_data", "user_profile"],
#             template="""
#             You are a financial advisor. Based on the stock analysis and the investor's financial profile,
#             determine whether this stock aligns with their investment goals. Provide:
#             - A summary of whether the stock fits their financial situation
#             - Any risks or mismatches to consider
#             - An investment recommendation (Buy, Hold, Avoid)
#             - Alternative investment suggestions if applicable
#
#             Stock Data:
#             {stock_data}
#
#             User Financial Profile:
#             {user_profile}
#             """
#         )
#
#         suitability_prompt = suitability_template.format(stock_data=st.session_state.formatted_data, user_profile=user_profile)
#
#         with st.spinner("Analyzing suitability..."):
#             try:
#                 suitability_response = llm.invoke(suitability_prompt)
#                 st.subheader("Analysis Result")
#                 st.write(suitability_response.content)
#             except Exception as e:
#                 st.error(f"Error generating analysis: {e}")
#                 st.info("Please ensure you have set up your Anthropic API key correctly.")
#
#     st.sidebar.subheader("Disclaimer")
#     st.sidebar.write("These insights are generated based on available data and AI-driven analysis. Please exercise discretion in making financial decisions.")

# ------ STOCK ANALYSIS PAGE ------
def stock_analysis_page():
    st.title("Stock Analysis")

    # Add back button
    if st.button("← Back to Home"):
        navigate_to('home')

    # Stock input
    stock_symbol = st.text_input("Enter Stock Symbol (e.g., RELIANCE, INFY, TCS)")

    # Show user profile summary
    st.sidebar.header("Your Investment Profile")
    for key, value in st.session_state.user_profile.items():
        st.sidebar.write(f"**{key.replace('_', ' ').title()}:** {value}")

    if st.sidebar.button("Edit Profile"):
        navigate_to('profile')

    if st.button("Analyze Stock") and stock_symbol:
        try:
            with st.spinner("Fetching and analyzing stock data..."):
                analyzer = StockAnalyzer(stock_symbol)
                st.session_state.analysis_results = analyzer.analyze()
                st.session_state.formatted_data = format_data_for_llm(st.session_state.analysis_results)
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")

    if st.session_state.analysis_results:
        # Display company name
        screener_data = st.session_state.analysis_results.get("screener_data")
        if screener_data:
            st.header(screener_data.get("Company Name", stock_symbol))

        # Plot stock chart
        yahoo_data = st.session_state.analysis_results.get("yahoo_finance_data")
        if yahoo_data and "historical_data" in yahoo_data:
            st.plotly_chart(plot_stock_chart(yahoo_data["historical_data"]))

        # Display key metrics
        if screener_data and "Key Metrics" in screener_data:
            st.subheader("Key Metrics")
            metrics_df = pd.DataFrame(list(screener_data["Key Metrics"].items()), columns=["Metric", "Value"])
            st.dataframe(metrics_df)

        # Investment Suitability Analysis
        st.header("Investment Suitability Analysis")
        user_profile = format_user_profile(st.session_state.user_profile)

        api_key =  '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'
        llm = ChatAnthropic(anthropic_api_key=api_key, model="claude-3-sonnet-20240229")

        suitability_template = PromptTemplate(
            input_variables=["stock_data", "user_profile"],
            template="""
            You are a financial advisor. Based on the stock analysis and the investor's financial profile, 
            determine whether this stock aligns with their investment goals. Provide:
            - A summary of whether the stock fits their financial situation
            - Any risks or mismatches to consider
            - An investment recommendation (Buy, Hold, Avoid) 
            - Alternative investment suggestions if applicable
            
            Stock Data:
            {stock_data}
            
            User Financial Profile:
            {user_profile}
            """
        )

        suitability_prompt = suitability_template.format(stock_data=st.session_state.formatted_data, user_profile=user_profile)

        with st.spinner("Analyzing suitability..."):
            try:
                suitability_response = llm.invoke(suitability_prompt)
                st.subheader("Analysis Result")
                st.write(suitability_response.content)
            except Exception as e:
                st.error(f"Error generating analysis: {e}")
                st.info("Please ensure you have set up your Anthropic API key correctly.")

        # NEW CHATBOT FEATURE
        st.header("Ask More Questions")
        st.write("Feel free to ask any specific questions about this stock:")

        # Initialize the chat history in session state if it doesn't exist
        if 'chat_history' not in st.session_state:
            st.session_state.chat_history = []

        # Display chat history
        for q, a in st.session_state.chat_history:
            st.info(f"**Question:** {q}")
            st.success(f"**Answer:** {a}")

        user_question = st.text_input("Your question:")

        if st.button("Get Answer") and user_question:
            with st.spinner("Analyzing your question..."):
                try:
                    follow_up_template = PromptTemplate(
                        input_variables=["stock_data", "user_profile", "question"],
                        template="""You are a financial analyst. Using the following stock data and user profile:

                        Stock Data:
                        {stock_data}
                        
                        User Profile:
                        {user_profile}

                        Please answer this specific question about the stock:
                        {question}

                        Provide a clear and concise answer based on the available data. DONT SAY THAT PLS CONDUCT UR OWN STUDY OR CONSULT ANY 
                        FINANCIAL ADVISOR, GIVE YOUR VIEWS CORRECTLY BASED ON YOUR ANALYSIS.
                        At the end you can mention that these are just advises from your analysis."""
                    )

                    follow_up_prompt = follow_up_template.format(
                        stock_data=st.session_state.formatted_data,
                        user_profile=user_profile,
                        question=user_question
                    )

                    follow_up_response = llm.invoke(follow_up_prompt)
                    answer = follow_up_response.content

                    # Add to chat history
                    st.session_state.chat_history.append((user_question, answer))

                    # Display the new question and answer
                    st.info(f"**Question:** {user_question}")
                    st.success(f"**Answer:** {answer}")

                    # Clear the input box by rerunning the app
                    st.rerun()

                except Exception as e:
                    st.error(f"Error generating answer: {e}")
                    st.info("Please ensure you have set up your Anthropic API key correctly.")

    st.sidebar.subheader("Disclaimer")
    st.sidebar.write("These insights are generated based on available data and AI-driven analysis. Please exercise discretion in making financial decisions.")
# ------ PROFILE PAGE ------
def profile_page():
    st.title("Your Investment Profile")

    # Add back button
    if st.button("← Back to Home"):
        navigate_to('home')

    st.write("Update your financial information to get more personalized investment recommendations.")

    with st.form("profile_form"):
        age = st.number_input("Age", min_value=18, max_value=100, value=st.session_state.user_profile['age'])
        marital_status = st.selectbox("Marital Status",
                                     ["Single", "Married", "Divorced", "Widowed"],
                                     index=["Single", "Married", "Divorced", "Widowed"].index(st.session_state.user_profile['marital_status']))
        income = st.number_input("Annual Income (in ₹)", min_value=0, value=st.session_state.user_profile['income'])
        expenses = st.number_input("Annual Expenses (in ₹)", min_value=0, value=st.session_state.user_profile['expenses'])
        time_horizon = st.selectbox("Investment Time Horizon",
                                   ["Short-term (0-3 years)", "Medium-term (3-7 years)", "Long-term (7+ years)"],
                                   index=["Short-term (0-3 years)", "Medium-term (3-7 years)", "Long-term (7+ years)"].index(st.session_state.user_profile['time_horizon']))
        risk_aversion = st.selectbox("Risk Appetite",
                                    ["Low", "Moderate", "High"],
                                    index=["Low", "Moderate", "High"].index(st.session_state.user_profile['risk_aversion']))
        dependents = st.number_input("Number of Dependents", min_value=0, value=st.session_state.user_profile['dependents'])
        health_status = st.selectbox("Health Status",
                                    ["Good", "Moderate", "Poor"],
                                    index=["Good", "Moderate", "Poor"].index(st.session_state.user_profile['health_status']))
        financial_goals = st.text_area("Describe Your Financial Goals", value=st.session_state.user_profile['financial_goals'])

        submitted = st.form_submit_button("Save Profile")

        if submitted:
            st.session_state.user_profile = {
                'age': age,
                'marital_status': marital_status,
                'income': income,
                'expenses': expenses,
                'time_horizon': time_horizon,
                'risk_aversion': risk_aversion,
                'dependents': dependents,
                'health_status': health_status,
                'financial_goals': financial_goals
            }
            st.success("Profile updated successfully!")

    # Basic financial calculations
    if st.session_state.user_profile['income'] > 0:
        savings_rate = (st.session_state.user_profile['income'] - st.session_state.user_profile['expenses']) / st.session_state.user_profile['income'] * 100
        st.subheader("Financial Insights")
        col1, col2 = st.columns(2)
        col1.metric("Annual Savings", f"₹{st.session_state.user_profile['income'] - st.session_state.user_profile['expenses']:,}")
        col2.metric("Savings Rate", f"{savings_rate:.1f}%")

        # Investment capacity gauge
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = savings_rate,
            title = {'text': "Investment Capacity"},
            gauge = {
                'axis': {'range': [0, 50]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 10], 'color': "red"},
                    {'range': [10, 20], 'color': "orange"},
                    {'range': [20, 30], 'color': "yellow"},
                    {'range': [30, 50], 'color': "green"}
                ]
            }
        ))
        st.plotly_chart(fig)

        if savings_rate < 10:
            st.warning("Your savings rate is low. Consider reviewing your expenses to increase your investment capacity.")
        elif savings_rate > 30:
            st.success("Great! You have a healthy savings rate which provides good investment capacity.")

# ------ MUTUAL FUNDS PAGE ------
def mutual_funds_page():
    st.title("Mutual Fund Explorer")

    # Add back button
    if st.button("← Back to Home"):
        navigate_to('home')

    # Initialize mutual fund analyzer
    mf_analyzer = MutualFundAnalyzer()

    # Get categories
    categories = mf_analyzer.get_all_categories()

    # Display filters
    selected_category = st.selectbox("Select Category", ["All"] + categories)

    # Get schemes based on selected category
    if selected_category == "All":
        # If no category is selected, show top categories
        st.subheader("Popular Mutual Fund Categories")
        top_categories = categories[:10]
        for category in top_categories:
            if st.button(category, key=f"cat_{category}"):
                st.session_state.selected_category = category
    else:
        # Show schemes for selected category
        schemes = mf_analyzer.get_schemes_by_category(selected_category)

        st.subheader(f"{selected_category} Funds")

        # Create a dataframe for better display
        schemes_df = pd.DataFrame(list(schemes.items()), columns=["Scheme Code", "Scheme Name"])
        schemes_df["Scheme Name"] = schemes_df["Scheme Name"].str.replace(f"{selected_category} - ", "")

        # Display schemes in a table with selection capability
        selected_scheme_index = st.selectbox("Select a scheme to view details",
                                           range(len(schemes_df)),
                                           format_func=lambda x: schemes_df.iloc[x]["Scheme Name"])

        selected_scheme_code = schemes_df.iloc[selected_scheme_index]["Scheme Code"]
        selected_scheme_name = schemes_df.iloc[selected_scheme_index]["Scheme Name"]

        # When a scheme is selected, fetch and display details
        if st.button("View Details", key="view_details"):
            with st.spinner("Fetching scheme details..."):
                scheme_info = mf_analyzer.get_scheme_details(selected_scheme_code)

                if scheme_info and "details" in scheme_info:
                    details = scheme_info["details"]

                    st.subheader(f"{details.get('scheme_name', selected_scheme_name)}")

                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Current NAV", f"₹{details.get('nav', 'N/A')}")
                        st.metric("Last Updated", details.get('last_updated', 'N/A'))

                    with col2:
                        st.metric("Scheme Category", details.get('scheme_category', 'N/A'))
                        st.metric("Scheme Type", details.get('scheme_type', 'N/A'))

                    st.subheader("NAV History")
                    nav_chart = plot_nav_history(scheme_info["nav_history"])
                    if nav_chart:
                        st.plotly_chart(nav_chart)
                    else:
                        st.info("NAV history data is not available for this scheme.")

                    # Calculate basic statistics if NAV history is available
                    if "nav_history" in scheme_info and "data" in scheme_info["nav_history"]:
                        nav_df = pd.DataFrame(scheme_info["nav_history"]["data"])
                        if not nav_df.empty:
                            nav_df['nav'] = pd.to_numeric(nav_df['nav'])
                            nav_df['date'] = pd.to_datetime(nav_df['date'], format='%d-%m-%Y')
                            nav_df = nav_df.sort_values('date')

                            # Calculate returns for different periods
                            if len(nav_df) > 0:
                                latest_nav = nav_df.iloc[-1]['nav']

                                # 1 month return
                                month_ago_index = max(0, len(nav_df) - 30)
                                month_ago_nav = nav_df.iloc[month_ago_index]['nav']
                                month_return = (latest_nav - month_ago_nav) / month_ago_nav * 100

                                # 6 month return
                                six_month_ago_index = max(0, len(nav_df) - 180)
                                six_month_ago_nav = nav_df.iloc[six_month_ago_index]['nav']
                                six_month_return = (latest_nav - six_month_ago_nav) / six_month_ago_nav * 100

                                # 1 year return
                                year_ago_index = max(0, len(nav_df) - 365)
                                year_ago_nav = nav_df.iloc[year_ago_index]['nav']
                                year_return = (latest_nav - year_ago_nav) / year_ago_nav * 100

                                st.subheader("Performance")
                                col1, col2, col3 = st.columns(3)
                                col1.metric("1 Month Return", f"{month_return:.2f}%")
                                col2.metric("6 Month Return", f"{six_month_return:.2f}%")
                                col3.metric("1 Year Return", f"{year_return:.2f}%")

                # Check if the fund matches user profile
                user_profile = st.session_state.user_profile
                match_score = 0
                match_reason = []

                # Risk assessment
                if "Equity" in selected_category and user_profile['risk_aversion'] == "High":
                    match_score += 2
                    match_reason.append("High risk equity fund matches your risk appetite")
                elif "Debt" in selected_category and user_profile['risk_aversion'] == "Low":
                    match_score += 2
                    match_reason.append("Low risk debt fund matches your risk appetite")
                elif "Balanced" in selected_category and user_profile['risk_aversion'] == "Moderate":
                    match_score += 2
                    match_reason.append("Moderate risk balanced fund matches your risk appetite")

                # Time horizon assessment
                if "ELSS" in selected_category and user_profile['time_horizon'] == "Medium-term (3-7 years)":
                    match_score += 1
                    match_reason.append("ELSS funds have a 3-year lock-in period, matching your medium-term horizon")
                elif "Liquid" in selected_category and user_profile['time_horizon'] == "Short-term (0-3 years)":
                    match_score += 1
                    match_reason.append("Liquid funds are suitable for short-term investment")
                elif ("Index" in selected_category or "Growth" in selected_category) and user_profile['time_horizon'] == "Long-term (7+ years)":
                    match_score += 1
                    match_reason.append("Index/Growth funds are ideal for long-term wealth creation")

                st.subheader("Profile Match Analysis")
                match_percentage = (match_score / 3) * 100

                fig = go.Figure(go.Indicator(
                    mode = "gauge+number",
                    value = match_percentage,
                    title = {'text': "Match with Your Profile"},
                    gauge = {
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "darkblue"},
                        'steps': [
                            {'range': [0, 33], 'color': "red"},
                            {'range': [33, 66], 'color': "yellow"},
                            {'range': [66, 100], 'color': "green"}
                        ]
                    }
                ))
                st.plotly_chart(fig)

                if match_reason:
                    st.subheader("Reasons for Match")
                    for reason in match_reason:
                        st.write(f"- {reason}")

                if match_percentage < 33:
                    st.warning("This fund may not align well with your investment profile.")
                elif match_percentage > 66:
                    st.success("This fund appears to be a good match for your investment profile.")
                else:
                    st.info("This fund partially aligns with your investment profile.")

    st.sidebar.subheader("Disclaimer")
    st.sidebar.write("Past performance is not indicative of future results. Please read scheme information document before investing.")

# ------ MAIN APP LOGIC ------
def main():
    # Display the appropriate page based on session state
    if st.session_state.page == 'home':
        home_page()
    elif st.session_state.page == 'stocks':
        stock_analysis_page()
    elif st.session_state.page == 'profile':
        profile_page()
    elif st.session_state.page == 'mutual_funds':
        mutual_funds_page()

if __name__ == "__main__":
    main()
