import os
import json
import pandas as pd
from groq import Groq
import textwrap

# Initialize Groq client
client = Groq(api_key=os.getenv("GROQ_API_KEY", "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"))

def get_sip_recommendation(age, profession, monthly_income, monthly_expenses, risk_tolerance, investment_horizon, investment_goal):
    """
    Get SIP amount recommendation from Groq LLM based on user profile.
    
    Parameters:
    -----------
    age : int
        User's age
    profession : str
        User's profession
    monthly_income : float
        User's monthly income
    monthly_expenses : float
        User's monthly expenses
    risk_tolerance : str
        User's risk tolerance level
    investment_horizon : int
        User's investment horizon in years
    investment_goal : str
        User's investment goal
    
    Returns:
    --------
    dict
        Dictionary containing recommended SIP amount and reasoning
    """
    # Calculate disposable income
    disposable_income = monthly_income - monthly_expenses
    
    # Create prompt for LLM
    prompt = textwrap.dedent(f"""
    You are a financial advisor specializing in mutual fund investments in India. 
    Based on the following user profile, recommend a suitable monthly SIP (Systematic Investment Plan) amount.
    
    User Profile:
    - Age: {age} years
    - Profession: {profession}
    - Monthly Income: ₹{monthly_income}
    - Monthly Expenses: ₹{monthly_expenses}
    - Disposable Income: ₹{disposable_income}
    - Risk Tolerance: {risk_tolerance}
    - Investment Horizon: {investment_horizon} years
    - Investment Goal: {investment_goal}
    
    Please provide:
    1. A recommended monthly SIP amount in INR (as a specific number).
    2. A brief explanation of your recommendation (2-3 paragraphs).
    
    Format your response as a JSON object with two keys: "amount" (a number) and "reasoning" (a string).
    Do not include any other text outside the JSON object.
    """)
    
    try:
        # Make API call to Groq
        completion = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[
                {"role": "system", "content": "You are a financial advisor specializing in mutual fund investments in India."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.1,
        )
        
        # Parse response
        response_text = completion.choices[0].message.content
        response_json = json.loads(response_text)
        
        # Extract SIP amount and reasoning
        sip_amount = response_json.get("amount", 0)
        reasoning = response_json.get("reasoning", "Unable to generate reasoning.")
        
        return {
            "amount": sip_amount,
            "reasoning": reasoning
        }
    
    except Exception as e:
        # Fallback recommendation based on 50-30-20 rule
        # 50% needs, 30% wants, 20% savings/investments
        recommended_amount = int(disposable_income * 0.2)
        
        # Adjust based on age (younger can invest more %)
        if age < 30:
            recommended_amount = int(disposable_income * 0.25)
        elif age > 50:
            recommended_amount = int(disposable_income * 0.15)
        
        # Round to nearest 1000
        recommended_amount = max(1000, round(recommended_amount, -3))
        
        return {
            "amount": recommended_amount,
            "reasoning": f"Based on your monthly income of ₹{monthly_income} and expenses of ₹{monthly_expenses}, your disposable income is ₹{disposable_income}. Following the 50-30-20 rule, approximately 20% of your disposable income (₹{recommended_amount}) is recommended for investments. This amount is adjusted based on your age, risk tolerance, and investment horizon."
        }

def get_portfolio_optimization(recommended_funds, risk_tolerance, investment_horizon, investment_goal):
    """
    Get portfolio optimization suggestions from Groq LLM.
    
    Parameters:
    -----------
    recommended_funds : list
        List of recommended fund dictionaries
    risk_tolerance : str
        User's risk tolerance level
    investment_horizon : int
        User's investment horizon in years
    investment_goal : str
        User's investment goal
    
    Returns:
    --------
    dict
        Dictionary containing allocation percentages and explanation
    """
    # Create a simplified representation of the funds for the prompt
    funds_info = []
    for i, fund in enumerate(recommended_funds):
        fund_info = {
            "fund_num": i + 1,
            "name": fund['scheme_name'],
            "category": fund['category'],
            "sub_category": fund['sub_category'],
            "risk_level": fund['risk_level'],
            "returns_1yr": fund['returns_1yr'],
            "returns_3yr": fund['returns_3yr'],
            "returns_5yr": fund['returns_5yr'] if not pd.isna(fund['returns_5yr']) else "N/A",
            "expense_ratio": fund['expense_ratio'],
            "sharpe": fund['sharpe'],
            "alpha": fund['alpha'],
            "beta": fund['beta'],
        }
        funds_info.append(fund_info)
    
    # Create prompt for LLM
    prompt = textwrap.dedent(f"""
    You are a portfolio manager specializing in mutual fund investments in India.
    Based on the following user profile and recommended mutual funds, suggest an optimal allocation percentage for each fund.
    
    User Profile:
    - Risk Tolerance: {risk_tolerance}
    - Investment Horizon: {investment_horizon} years
    - Investment Goal: {investment_goal}
    
    Recommended Funds:
    {json.dumps(funds_info, indent=2)}
    
    Please provide:
    1. Allocation percentages for each fund (must sum to 100%)
    2. A brief explanation of your allocation strategy (2-3 paragraphs)
    3. Expected annual return for the portfolio
    
    Format your response as a JSON object with three keys:
    - "allocation": an array of 5 percentages (as integers) that sum to 100
    - "explanation": a string explaining the allocation strategy
    - "expected_return": a string representing the expected annual return percentage
    
    Do not include any other text outside the JSON object.
    """)
    
    try:
        # Make API call to Groq
        completion = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[
                {"role": "system", "content": "You are a portfolio manager specializing in mutual fund investments in India."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.1,
        )
        
        # Parse response
        response_text = completion.choices[0].message.content
        response_json = json.loads(response_text)
        
        # Extract allocation and explanation
        allocation = response_json.get("allocation", [20, 20, 20, 20, 20])
        explanation = response_json.get("explanation", "Unable to generate explanation.")
        expected_return = response_json.get("expected_return", "8-12")
        
        return {
            "allocation": allocation,
            "explanation": explanation,
            "expected_return": expected_return
        }
    
    except Exception as e:
        # Fallback allocation based on risk tolerance
        if risk_tolerance in ["Very Low", "Low"]:
            allocation = [40, 30, 15, 10, 5]  # Conservative allocation
            expected_return = "7-9"
        elif risk_tolerance == "Moderate":
            allocation = [30, 25, 20, 15, 10]  # Balanced allocation
            expected_return = "9-11"
        else:  # High or Very High
            allocation = [20, 20, 20, 20, 20]  # Aggressive allocation
            expected_return = "11-14"
        
        # Create a simple explanation
        explanation = f"""
        This allocation is designed for a {risk_tolerance.lower()} risk profile with an investment horizon of {investment_horizon} years and a goal of {investment_goal.lower()}.
        
        The portfolio is diversified across different fund categories to balance risk and return. Funds with higher historical returns and better risk-adjusted metrics (Sharpe ratio, Alpha) are given higher allocations.
        
        With this allocation, you can expect an annual return of approximately {expected_return}%, though actual returns may vary based on market conditions.
        """
        
        return {
            "allocation": allocation,
            "explanation": explanation,
            "expected_return": expected_return
        }
