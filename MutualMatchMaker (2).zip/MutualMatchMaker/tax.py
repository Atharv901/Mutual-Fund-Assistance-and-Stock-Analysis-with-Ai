import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class TaxPlanner:
    def __init__(self):
        self.tax_slabs = {
            'STCG': 0.15,  # Short Term Capital Gains (equity)
            'LTCG': 0.10,  # Long Term Capital Gains (equity) above 1L
            'DEBT_STCG': None,  # Based on income slab
            'DEBT_LTCG': 0.20  # With indexation
        }
        
        self.cii_table = {
            2015: 254, 2016: 264, 2017: 272, 2018: 280, 2019: 289, 2020: 301,
            2021: 317, 2022: 331, 2023: 348, 2024: 364, 2025: 369, 2026: 381,
            2027: 393, 2028: 405, 2029: 417, 2030: 429, 2031: 441, 2032: 453,
            2033: 465, 2034: 477, 2035: 490, 2036: 502, 2037: 514, 2038: 526, 2039: 538
        }

    def get_cii(self, date):
        year = date.year
        return self.cii_table.get(year, self.cii_table[max(self.cii_table)])

    def calculate_capital_gains(self, purchase_price, current_price, units, purchase_date, asset_type='EQUITY', income_tax_rate=0.30):
        """Calculate capital gains and applicable tax
        
        Args:
            purchase_price: Purchase price per unit
            current_price: Current price per unit
            units: Number of units
            purchase_date: Date of purchase in YYYY-MM-DD format
            asset_type: 'EQUITY' or 'DEBT'
            income_tax_rate: User's income tax rate (as decimal) for debt fund taxation
        """
        purchase_date_dt = datetime.strptime(purchase_date, '%Y-%m-%d')
        holding_period = (datetime.now() - purchase_date_dt).days
        capital_gains = (current_price - purchase_price) * units

        if asset_type == 'EQUITY':
            if holding_period > 365:
                # LTCG for equity
                if capital_gains > 100000:
                    tax = (capital_gains - 100000) * self.tax_slabs['LTCG']
                else:
                    tax = 0
                gain_type = 'LTCG'
            else:
                tax = capital_gains * self.tax_slabs['STCG']
                gain_type = 'STCG'
        else:  # DEBT
            # All capital gains on non-equity MFs (both short and long term)
            # are now taxed as per income slab rate
            tax = capital_gains * income_tax_rate
            
            # Still differentiate between short and long term for reporting purposes
            if holding_period > 1095:  # 3 years
                gain_type = 'DEBT_LTCG'
            else:
                gain_type = 'DEBT_STCG'
                
        return {
            'capital_gains': round(capital_gains, 2),
            'tax_liability': round(tax, 2),
            'gain_type': gain_type,
            'holding_period_days': holding_period
        }

    def get_elss_recommendations(self, funds_df, risk_profile='Moderate', top_n=5):
        # Filter for ELSS funds using sub_category
        elss_funds = funds_df[
            funds_df['sub_category'].str.contains('ELSS', case=False, na=False)
        ].copy()
        
        # If no ELSS funds found, return an empty dataframe
        if elss_funds.empty:
            return pd.DataFrame()
        
        # Define risk weights
        risk_weights = {
            'Conservative': {'returns': 0.3, 'risk': 0.7},
            'Moderate': {'returns': 0.5, 'risk': 0.5},
            'Aggressive': {'returns': 0.7, 'risk': 0.3}
        }
        
        weights = risk_weights.get(risk_profile, risk_weights['Moderate'])
        
        # Fill NaN values to avoid calculation errors and convert to numeric
        for col in ['returns_3yr', 'returns_5yr', 'sharpe']:
            if col in elss_funds.columns:
                elss_funds[col] = pd.to_numeric(elss_funds[col], errors='coerce').fillna(0)
        
        # Create return score using 3yr and 5yr returns
        elss_funds['return_score'] = 0.0  # Initialize with zeroes
        if 'returns_3yr' in elss_funds.columns and 'returns_5yr' in elss_funds.columns:
            elss_funds['return_score'] = (
                elss_funds['returns_3yr'] * 0.6 + 
                elss_funds['returns_5yr'] * 0.4
            ).astype(float)
        
        # Risk score based on Sharpe ratio
        elss_funds['risk_score'] = 0.0  # Initialize with zeroes
        if 'sharpe' in elss_funds.columns:
            elss_funds['risk_score'] = pd.to_numeric(elss_funds['sharpe'], errors='coerce').fillna(0)
        
        # Normalize scores if there's more than one fund
        if len(elss_funds) > 1:
            # Normalize return score
            return_min = elss_funds['return_score'].min()
            return_max = elss_funds['return_score'].max()
            if return_max > return_min:
                elss_funds['return_score'] = (elss_funds['return_score'] - return_min) / (return_max - return_min)
            
            # Normalize risk score
            risk_min = elss_funds['risk_score'].min()
            risk_max = elss_funds['risk_score'].max()
            if risk_max > risk_min:
                elss_funds['risk_score'] = (elss_funds['risk_score'] - risk_min) / (risk_max - risk_min)
        
        # Calculate final score
        elss_funds['final_score'] = (
            weights['returns'] * elss_funds['return_score'] + 
            weights['risk'] * elss_funds['risk_score']
        ).astype(float)  # Ensure final_score is float type
        
        # Sort by final score and return top N
        return elss_funds.sort_values('final_score', ascending=False).head(top_n)
    
    def suggest_tax_harvesting(self, portfolio_df, threshold=-5.0):
        today = datetime.now()
        harvest_opportunities = []
        
        for _, investment in portfolio_df.iterrows():
            purchase_date = datetime.strptime(investment['purchase_date'], '%Y-%m-%d')
            holding_period = (today - purchase_date).days
            
            returns = ((investment['current_nav'] - investment['purchase_nav']) / 
                       investment['purchase_nav'] * 100)
            
            if returns < threshold and holding_period > 365:
                harvest_opportunities.append({
                    'scheme_name': investment['scheme_name'],
                    'current_loss': round((investment['current_nav'] - investment['purchase_nav']) * 
                                          investment['units'], 2),
                    'holding_period_days': holding_period,
                    'suggested_action': 'Consider selling to book loss and reinvest'
                })
                
        return harvest_opportunities
