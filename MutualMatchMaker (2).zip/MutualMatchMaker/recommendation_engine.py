import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from scipy.spatial.distance import cdist

def recommend_funds(df, risk_level, investment_horizon, investment_goal, investment_type, user_age=30):
    """
    Recommends top 5 mutual funds based on user profile using a hybrid approach:
    1. KNN for similarity matching
    2. Random Forest for classification based on risk/age profiles
    3. Custom scoring for final ranking
    
    Parameters:
    -----------
    df : pandas.DataFrame
        DataFrame containing mutual fund data
    risk_level : int
        User's risk tolerance level (1-6)
    investment_horizon : int
        User's investment horizon in years
    investment_goal : str
        User's investment goal
    investment_type : str
        'SIP' or 'Lumpsum'
    user_age : int, optional
        User's age in years (default 30)
    
    Returns:
    --------
    list
        List of dictionaries containing top 5 recommended funds
    """
    # Create a copy of the dataframe to avoid modifying the original
    data = df.copy()
    
    # Filter funds based on investment horizon
    if investment_horizon <= 1:
        # For very short-term, prefer liquid, overnight and ultra short duration funds
        filtered_data = data[
            (data['category'] == 'Debt') & 
            (data['sub_category'].isin(['Liquid Mutual Funds', 'Overnight Mutual Funds', 'Ultra Short Duration Funds']))
        ]
    elif investment_horizon <= 3:
        # For short-term, prefer short duration debt funds and balanced advantage funds
        filtered_data = data[
            ((data['category'] == 'Debt') & 
             (data['sub_category'].isin(['Short Duration Funds', 'Banking and PSU Mutual Funds', 'Corporate Bond Mutual Funds']))) |
            ((data['category'] == 'Hybrid') & 
             (data['sub_category'].isin(['Arbitrage Mutual Funds', 'Dynamic Asset Allocation or Balanced Advantage'])))
        ]
    elif investment_horizon <= 7:
        # For medium-term, include equity and hybrid funds
        filtered_data = data[
            (data['category'].isin(['Equity', 'Hybrid', 'Debt'])) &
            ~(data['sub_category'].isin(['Overnight Mutual Funds', 'Liquid Mutual Funds']))
        ]
    else:
        # For long-term, primarily equity funds
        filtered_data = data[data['category'].isin(['Equity', 'Hybrid'])]
    
    # If no funds match criteria, use the entire dataset
    if filtered_data.shape[0] < 5:
        filtered_data = data
    
    # Filter by investment goal
    if investment_goal == "Tax Saving":
        # For tax saving, prefer ELSS funds
        tax_saving_funds = filtered_data[filtered_data['sub_category'] == 'ELSS Mutual Funds']
        if tax_saving_funds.shape[0] >= 5:
            filtered_data = tax_saving_funds
    elif investment_goal == "Retirement":
        # For retirement, prefer retirement funds and equity funds with good long-term returns
        retirement_funds = filtered_data[
            (filtered_data['sub_category'] == 'Retirement Funds') | 
            ((filtered_data['category'] == 'Equity') & (filtered_data['returns_5yr'] > filtered_data['returns_5yr'].median()))
        ]
        if retirement_funds.shape[0] >= 5:
            filtered_data = retirement_funds
    elif investment_goal == "Children's Education":
        # For children's education, prefer children's funds and equity funds with good long-term returns
        childrens_funds = filtered_data[
            (filtered_data['sub_category'] == 'Childrens Funds') | 
            ((filtered_data['category'] == 'Equity') & (filtered_data['returns_5yr'] > filtered_data['returns_5yr'].median()))
        ]
        if childrens_funds.shape[0] >= 5:
            filtered_data = childrens_funds
    
    # Filter by risk level with an age-adjusted approach
    risk_range = 1  # Allow for some flexibility in risk level matching
    
    # For young investors with high risk tolerance, include more aggressive funds
    if user_age < 35 and risk_level >= 5:
        # Include more small cap funds which are suitable for young, high-risk investors
        small_cap_funds = data[data['sub_category'] == 'Small Cap Mutual Funds']
        mid_cap_funds = data[data['sub_category'] == 'Mid Cap Mutual Funds']
        
        # Combine with risk-filtered data, ensuring we have enough small/mid cap funds
        # which are appropriate for young high-risk investors
        risk_filtered_data = pd.concat([
            filtered_data[
                (filtered_data['risk_level'] >= max(1, risk_level - risk_range)) & 
                (filtered_data['risk_level'] <= min(6, risk_level + risk_range))
            ],
            small_cap_funds,
            mid_cap_funds
        ]).drop_duplicates()
    else:
        risk_filtered_data = filtered_data[
            (filtered_data['risk_level'] >= max(1, risk_level - risk_range)) & 
            (filtered_data['risk_level'] <= min(6, risk_level + risk_range))
        ]
    
    # If too few funds after risk filtering, use the previous filtered data
    if risk_filtered_data.shape[0] < 5:
        risk_filtered_data = filtered_data
    
    # Filter by investment type (SIP or Lumpsum)
    if investment_type == 'SIP':
        # Sort by minimum SIP amount (lower is better)
        initial_filtered_data = risk_filtered_data.sort_values('min_sip')
    else:  # Lumpsum
        # Sort by minimum lumpsum amount (lower is better)
        initial_filtered_data = risk_filtered_data.sort_values('min_lumpsum')
    
    # Prepare data for ML algorithms
    # Select relevant features for recommendation
    features = [
        'expense_ratio', 'risk_level', 'rating', 'returns_1yr', 
        'returns_3yr', 'returns_5yr', 'sharpe', 'alpha', 'sd', 'beta'
    ]
    
    # Handle missing values and ensure numeric data
    feature_data = initial_filtered_data[features].copy()
    
    # Convert all columns to numeric, coercing errors to NaN
    feature_data = feature_data.apply(pd.to_numeric, errors='coerce')
    
    # Fill missing values with column means
    feature_data = feature_data.fillna(feature_data.mean())
    
    # Create age and risk profile based features for random forest
    # This allows us to better target specific fund types (like small cap) based on age/risk
    age_risk_labels = []
    
    for _, fund in initial_filtered_data.iterrows():
        # Create a label based on fund category and risk level
        # This will help the random forest learn which funds are suitable for different profiles
        if fund['sub_category'] == 'Small Cap Mutual Funds' and fund['risk_level'] >= 5:
            # Small cap funds are suitable for young high-risk investors
            label = 1 if user_age < 40 and risk_level >= 5 else 0
        elif fund['sub_category'] == 'Mid Cap Mutual Funds' and fund['risk_level'] >= 4:
            # Mid cap funds are suitable for young/middle-aged moderate to high-risk investors
            label = 1 if user_age < 50 and risk_level >= 4 else 0
        elif fund['sub_category'] in ['Large Cap Mutual Funds', 'Large & Mid Cap Funds'] and fund['risk_level'] >= 3:
            # Large cap funds are suitable for most investors
            label = 1 if risk_level >= 3 else 0
        elif fund['category'] == 'Debt' and fund['risk_level'] <= 3:
            # Debt funds are suitable for low-risk or older investors
            label = 1 if risk_level <= 3 or user_age > 55 else 0
        elif fund['category'] == 'Hybrid':
            # Hybrid funds are suitable for moderate risk investors
            label = 1 if 2 <= risk_level <= 5 else 0
        else:
            # Default suitability based on risk level match
            label = 1 if abs(fund['risk_level'] - risk_level) <= 1 else 0
            
        age_risk_labels.append(label)
    
    # Train a Random Forest classifier on fund features vs. age/risk suitability
    # This helps identify funds that match specific age/risk profiles
    X_rf = feature_data.values
    y_rf = np.array(age_risk_labels)
    
    # Use a small forest for quick prediction
    rf = RandomForestClassifier(n_estimators=50, max_depth=5, random_state=42)
    
    # If we have enough samples, train the model
    if len(np.unique(y_rf)) > 1 and len(y_rf) > 10:
        rf.fit(X_rf, y_rf)
        # Get probability scores for suitability
        rf_probs = rf.predict_proba(X_rf)[:, 1]  # Probability of class 1 (suitable)
    else:
        # If not enough data for training, use a simpler approach
        rf_probs = np.ones(len(X_rf))
    
    # Scale features for KNN
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(feature_data)
    
    # Create a user profile vector based on risk level, investment horizon and age
    user_profile = np.zeros(len(features))
    
    # Customize user profile based on age, risk level, and investment horizon
    if user_age < 35 and risk_level >= 5:
        # Young investor with high risk tolerance: prefer high-growth, small/mid cap funds
        user_profile[0] = 0  # expense_ratio (not a priority for high-growth strategy)
        user_profile[1] = 6  # risk_level (max risk for growth)
        user_profile[2] = 3  # rating (good, but not the primary focus)
        user_profile[3] = 4  # returns_1yr (very high returns)
        user_profile[4] = 4  # returns_3yr (very high returns)
        user_profile[5] = 4  # returns_5yr (very high returns)
        user_profile[6] = 2  # sharpe (moderate - willing to accept more volatility)
        user_profile[7] = 4  # alpha (very high - looking for outperformance)
        user_profile[8] = 2  # sd (higher risk is desirable for growth)
        user_profile[9] = 2  # beta (higher market sensitivity is acceptable)
    elif user_age < 50 and risk_level >= 4:
        # Middle-aged investor with good risk tolerance: balance growth and stability
        user_profile[0] = -1  # expense_ratio (somewhat important)
        user_profile[1] = 5  # risk_level (high risk but not maximum)
        user_profile[2] = 4  # rating (important)
        user_profile[3] = 3  # returns_1yr (high returns)
        user_profile[4] = 3.5  # returns_3yr (high returns)
        user_profile[5] = 3.5  # returns_5yr (high returns)
        user_profile[6] = 3  # sharpe (good risk-adjusted returns)
        user_profile[7] = 3  # alpha (high)
        user_profile[8] = 1  # sd (moderate risk is acceptable)
        user_profile[9] = 1.5  # beta (moderate market sensitivity)
    elif risk_level <= 2:  # Low risk profile (any age)
        # Prefer funds with low expense ratio, low risk, low SD, low beta
        user_profile[0] = -2  # expense_ratio (lower is better)
        user_profile[1] = risk_level  # risk_level
        user_profile[2] = 4  # rating (higher is better)
        user_profile[3] = 1  # returns_1yr (moderate returns)
        user_profile[4] = 1  # returns_3yr (moderate returns)
        user_profile[5] = 1  # returns_5yr (moderate returns)
        user_profile[6] = 2  # sharpe (moderate)
        user_profile[7] = 1  # alpha (moderate)
        user_profile[8] = -1  # sd (lower is better)
        user_profile[9] = 0.5  # beta (lower is better)
    elif risk_level <= 4:  # Moderate risk
        # Prefer funds with moderate values
        user_profile[0] = -1  # expense_ratio (lower is better)
        user_profile[1] = risk_level  # risk_level
        user_profile[2] = 4  # rating (higher is better)
        user_profile[3] = 2  # returns_1yr (good returns)
        user_profile[4] = 2  # returns_3yr (good returns)
        user_profile[5] = 2  # returns_5yr (good returns)
        user_profile[6] = 2.5  # sharpe (good)
        user_profile[7] = 2  # alpha (good)
        user_profile[8] = 0  # sd (moderate)
        user_profile[9] = 1  # beta (moderate)
    else:  # High risk (not young)
        # Prefer funds with high returns, balanced with some stability
        user_profile[0] = 0  # expense_ratio (not a priority)
        user_profile[1] = risk_level  # risk_level
        user_profile[2] = 4  # rating (higher is better)
        user_profile[3] = 3  # returns_1yr (high returns)
        user_profile[4] = 3  # returns_3yr (high returns)
        user_profile[5] = 3  # returns_5yr (high returns)
        user_profile[6] = 3  # sharpe (high)
        user_profile[7] = 3  # alpha (high)
        user_profile[8] = 1  # sd (higher risk is acceptable)
        user_profile[9] = 1.5  # beta (higher is acceptable)
    
    # Scale user profile
    scaled_user_profile = scaler.transform(user_profile.reshape(1, -1))
    
    # Calculate distances for each fund to the user profile
    distances = cdist(scaled_features, scaled_user_profile, 'euclidean').flatten()
    
    # Create a composite score combining:
    # 1. KNN distances (lower is better)
    # 2. Random Forest probabilities (higher is better)
    # 3. Custom scoring for specific attributes
    
    # Normalize distances to 0-1 scale (inverted so higher is better)
    max_dist = np.max(distances) if len(distances) > 0 else 1
    norm_distances = 1 - (distances / max_dist)
    
    # Ensure 'sharpe' column exists and fill missing values with 0
    if 'sharpe' in initial_filtered_data.columns:
        initial_filtered_data['sharpe'] = initial_filtered_data['sharpe'].fillna(0)
    else:
        initial_filtered_data['sharpe'] = 0
    initial_filtered_data['sharpe'] = pd.to_numeric(df['sharpe'], errors='coerce').fillna(0)
    # Calculate custom scores based on fund attributes and user profile
    custom_scores = []
    
    for idx, fund in initial_filtered_data.iterrows():
        score = 0
    
        # Increase score for funds that match the desired risk profile
        score += (1 - abs(fund['risk_level'] - risk_level) / 6) * 2
    
        # For young investors with high risk tolerance, boost small and mid-cap funds
        if user_age < 35 and risk_level >= 5:
            if fund['sub_category'] == 'Small Cap Mutual Funds':
                score += 3
            elif fund['sub_category'] == 'Mid Cap Mutual Funds':
                score += 2
            elif 'Equity' in fund['category'] and fund['returns_3yr'] > 20:
                score += 1.5
    
        # For middle-aged investors, boost funds with good long-term track records
        if 35 <= user_age < 50:
            if fund['returns_5yr'] > 10 and fund['sharpe'] > 1.5:
                score += 1.5
    
        # For older investors, prioritize stability and consistent returns
        if user_age >= 50:
            if fund['category'] == 'Debt' or fund['category'] == 'Hybrid':
                score += 1
            if fund['sharpe'] > 2:  # High risk-adjusted returns
                score += 2
    
        # Boost funds with good ratings
        score += fund['rating'] * 0.3
    
        # Penalize very high expense ratios
        if fund['expense_ratio'] > 1.5:
            score -= 1
    
        custom_scores.append(score)
    
    # Combine all scores (with weights)
    combined_scores = (
        norm_distances * 0.4 +  # KNN component (40%)
        rf_probs * 0.3 +        # Random Forest component (30%)
        np.array(custom_scores) * 0.3 / 5  # Custom score component (30%), normalized to ~0-1 range
    )
    
    # Get indices of top 5 recommended funds
    top_indices = np.argsort(combined_scores)[-5:][::-1]
    
    # Get recommended funds
    recommended_funds = []
    for idx in top_indices:
        fund = initial_filtered_data.iloc[idx].to_dict()
        recommended_funds.append(fund)
    
    return recommended_funds
