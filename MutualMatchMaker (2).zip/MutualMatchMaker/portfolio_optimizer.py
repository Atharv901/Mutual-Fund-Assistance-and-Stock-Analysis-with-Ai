import numpy as np
import pandas as pd
from scipy.optimize import minimize

def optimize_portfolio(recommended_funds):
    """
    Optimize portfolio allocation using Sharpe ratio maximization.
    This is a simplified version of the Modern Portfolio Theory (MPT).
    
    Parameters:
    -----------
    recommended_funds : list
        List of dictionaries containing fund information
    
    Returns:
    --------
    list
        List of allocation percentages for each fund
    float
        Expected portfolio return
    float
        Expected portfolio risk (standard deviation)
    float
        Expected Sharpe ratio
    """
    # Extract returns and standard deviations
    returns = np.array([fund['returns_3yr'] for fund in recommended_funds])
    stds = np.array([fund['sd'] for fund in recommended_funds])
    
    # Use a default correlation matrix (simplified)
    n = len(recommended_funds)
    corr_matrix = np.ones((n, n)) * 0.5
    np.fill_diagonal(corr_matrix, 1)
    
    # Convert to covariance matrix
    cov_matrix = np.outer(stds, stds) * corr_matrix
    
    # Define objective function (negative Sharpe ratio to maximize)
    risk_free_rate = 4.0  # Assume 4% risk-free rate
    
    def objective(weights):
        portfolio_return = np.sum(weights * returns)
        portfolio_std = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
        sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_std
        return -sharpe_ratio
    
    # Constraints
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})  # Weights sum to 1
    
    # Bounds
    bounds = tuple((0, 1) for _ in range(n))  # Weights between 0 and 1
    
    # Initial guess
    initial_weights = np.array([1/n] * n)
    
    # Optimize
    result = minimize(objective, initial_weights, method='SLSQP', bounds=bounds, constraints=constraints)
    
    # Round to nearest 5%
    optimal_weights = result['x']
    rounded_weights = np.round(optimal_weights * 100 / 5) * 5
    
    # Adjust to ensure sum is 100%
    adjustment = 100 - np.sum(rounded_weights)
    if adjustment != 0:
        # Add or subtract from the largest weight
        idx = np.argmax(rounded_weights)
        rounded_weights[idx] += adjustment
    
    # Calculate expected return, risk and Sharpe ratio
    portfolio_return = np.sum(rounded_weights/100 * returns)
    portfolio_std = np.sqrt(np.dot((rounded_weights/100).T, np.dot(cov_matrix, (rounded_weights/100))))
    sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_std
    
    return rounded_weights.tolist(), portfolio_return, portfolio_std, sharpe_ratio
