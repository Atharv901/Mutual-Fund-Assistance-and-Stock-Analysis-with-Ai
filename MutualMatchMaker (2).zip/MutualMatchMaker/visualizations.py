import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

def plot_fund_performance(fund):
    """
    Plot fund performance over 1, 3, and 5 years.
    
    Parameters:
    -----------
    fund : dict
        Dictionary containing fund information
    """
    # Extract returns data
    returns_data = {
        'Period': ['1 Year', '3 Years', '5 Years'],
        'Returns (%)': [
            fund['returns_1yr'] if not pd.isna(fund['returns_1yr']) else 0,
            fund['returns_3yr'] if not pd.isna(fund['returns_3yr']) else 0,
            fund['returns_5yr'] if not pd.isna(fund['returns_5yr']) else 0
        ]
    }
    
    # Create DataFrame
    df = pd.DataFrame(returns_data)
    
    # Create bar chart
    fig = px.bar(
        df, 
        x='Period', 
        y='Returns (%)',
        text='Returns (%)',
        color='Returns (%)',
        color_continuous_scale='RdYlGn',
        height=250
    )
    
    # Update layout
    fig.update_layout(
        xaxis_title=None,
        yaxis_title='Returns (%)',
        showlegend=False,
        margin=dict(l=20, r=20, t=20, b=20)
    )
    
    # Display chart
    st.plotly_chart(fig, use_container_width=True)

def create_risk_return_scatter(funds):
    """
    Create a risk-return scatter plot for the recommended funds.
    
    Parameters:
    -----------
    funds : list
        List of dictionaries containing fund information
    """
    # Extract data
    data = {
        'Fund': [fund['scheme_name'][:25] + "..." for fund in funds],
        'Risk (SD)': [fund['sd'] for fund in funds],
        'Returns (3Y)': [fund['returns_3yr'] for fund in funds],
        'Category': [fund['category'] for fund in funds],
        'Sharpe Ratio': [fund['sharpe'] for fund in funds],
        'Risk Level': [fund['risk_level'] for fund in funds]
    }
    print(data)
    # Create DataFrame
    df = pd.DataFrame(data)
    df['Risk (SD)'] = pd.to_numeric(df['Risk (SD)'], errors='coerce').fillna(0)
    df['Sharpe Ratio'] = pd.to_numeric(df['Sharpe Ratio'], errors='coerce').fillna(0)
    # Create scatter plot
    fig = px.scatter(
        df,
        x='Risk (SD)',
        y='Returns (3Y)',
        size='Sharpe Ratio',
        color='Category',
        hover_name='Fund',
        text='Fund',
        height=500,
        size_max=25,
        color_discrete_sequence=px.colors.qualitative.Set1
    )
    
    # Add a reference diagonal line (risk = return)
    min_val = min(df['Risk (SD)'].min(), df['Returns (3Y)'].min())
    max_val = max(df['Risk (SD)'].max(), df['Returns (3Y)'].max())
    
    fig.add_trace(
        go.Scatter(
            x=[min_val, max_val],
            y=[min_val, max_val],
            mode='lines',
            line=dict(color='gray', dash='dash'),
            name='Risk = Return',
            hoverinfo='none'
        )
    )
    
    # Update layout
    fig.update_layout(
        title='Risk vs. Return Analysis',
        xaxis_title='Risk (Standard Deviation)',
        yaxis_title='3-Year Returns (%)',
        legend_title='Fund Category',
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    # Update text position
    fig.update_traces(
        textposition='top center',
        selector=dict(type='scatter')
    )
    
    # Display chart
    st.plotly_chart(fig, use_container_width=True)

def create_comparison_chart(funds):
    """
    Create a comparison chart for the recommended funds.
    
    Parameters:
    -----------
    funds : list
        List of dictionaries containing fund information
    """
    # Extract data
    fund_names = [fund['scheme_name'][:25] + "..." for fund in funds]
    returns_1yr = [fund['returns_1yr'] if not pd.isna(fund['returns_1yr']) else 0 for fund in funds]
    returns_3yr = [fund['returns_3yr'] if not pd.isna(fund['returns_3yr']) else 0 for fund in funds]
    returns_5yr = [fund['returns_5yr'] if not pd.isna(fund['returns_5yr']) else 0 for fund in funds]
    
    # Create figure
    fig = go.Figure()
    
    # Add bars for each time period
    fig.add_trace(go.Bar(
        x=fund_names,
        y=returns_1yr,
        name='1 Year Returns',
        marker_color='#FF9999'
    ))
    
    fig.add_trace(go.Bar(
        x=fund_names,
        y=returns_3yr,
        name='3 Year Returns',
        marker_color='#66B2FF'
    ))
    
    fig.add_trace(go.Bar(
        x=fund_names,
        y=returns_5yr,
        name='5 Year Returns',
        marker_color='#99FF99'
    ))
    
    # Update layout
    fig.update_layout(
        title='Returns Comparison',
        xaxis_title=None,
        yaxis_title='Returns (%)',
        legend_title='Time Period',
        barmode='group',
        height=500,
        margin=dict(l=20, r=20, t=50, b=100)
    )
    
    # Rotate x-axis labels for better readability
    fig.update_xaxes(tickangle=45)
    
    # Display chart
    st.plotly_chart(fig, use_container_width=True)
