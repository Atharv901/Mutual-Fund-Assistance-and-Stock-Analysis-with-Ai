from llm_integration import get_portfolio_optimization, get_sip_recommendation
from recommendation_engine import recommend_funds
import streamlit as st
import pandas as pd
import numpy as np
import os
from visualizations import create_comparison_chart, create_risk_return_scatter, plot_fund_performance
import yfinance as yf
import requests
from bs4 import BeautifulSoup
import mftool
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
from groq import Groq
from tax_planning import TaxPlanningUI

# Page configuration
st.set_page_config(
    page_title="Investment Advisor",
    page_icon="📈",
    layout="wide"
)

# Initialize session state
if 'user_profile' not in st.session_state:
    st.session_state.user_profile = None
if 'recommended_funds' not in st.session_state:
    st.session_state.recommended_funds = None
if 'portfolio_optimization' not in st.session_state:
    st.session_state.portfolio_optimization = None
if 'show_optimization' not in st.session_state:
    st.session_state.show_optimization = False
if 'all_funds' not in st.session_state:
    st.session_state.all_funds = None
if 'stock_analysis_results' not in st.session_state:
    st.session_state.stock_analysis_results = None

# Load data
@st.cache_data
def load_data():
    """Load and process mutual fund data from CSV"""
    try:
        df = pd.read_csv("attached_assets/comprehensive_mutual_funds_data.csv")
        
        # Convert percentage strings to float values if needed
        for col in df.columns:
            if 'returns' in col or 'expense_ratio' in col:
                if df[col].dtype == 'object':
                    df[col] = df[col].str.replace('%', '').astype(float)
        
        # Fill NaN values
        df = df.fillna({
            'returns_1yr': 0,
            'returns_3yr': 0,
            'returns_5yr': 0,
            'sortino': 0,
            'alpha': 0,
            'sharpe': 0,
            'sd': 0,
            'beta': 0,
            'rating': 0
        })
        
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return pd.DataFrame()  # Return empty DataFrame on error

# STOCK ANALYSIS FUNCTIONS
class StockAnalyzer:
    def __init__(self, stock_symbol):
        """Initialize the stock analyzer with a stock symbol"""
        self.stock_symbol = stock_symbol
        self.yf_symbol = stock_symbol + ".NS"  # Adding .NS for Yahoo Finance
        self.yf_stock = yf.Ticker(self.yf_symbol)

    def get_yahoo_data(self, period="1y"):
        """Fetch data from Yahoo Finance"""
        try:
            historical_data = self.yf_stock.history(period=period)
            historical_data['MA50'] = historical_data['Close'].rolling(window=50).mean()
            historical_data['MA200'] = historical_data['Close'].rolling(window=200).mean()
            financials = self.yf_stock.financials

            return {
                "historical_data": historical_data,
                "financials": financials
            }
        except Exception as e:
            st.error(f"Error fetching Yahoo Finance data: {e}")
            return None

    def get_screener_data(self):
        """Fetch data from Screener.in"""
        url = f"https://www.screener.in/company/{self.stock_symbol}/consolidated/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')
            company_name = soup.find('h1').text.strip()

            key_metrics = {}
            for row in soup.select('#top-ratios li'):
                key = row.find('span', class_='name').text.strip()
                value = row.find('span', class_='number').text.strip()
                key_metrics[key] = value

            tables = soup.find_all('table')
            table_data = {}

            for i, table in enumerate(tables):
                table_name = f"Table_{i + 1}"
                if table.find_previous('h2'):
                    table_name = table.find_previous('h2').text.strip()

                headers = [th.text.strip() for th in table.find_all('th')]
                rows = []

                for tr in table.find_all('tr'):
                    cells = tr.find_all('td')
                    if cells:
                        row = [cell.text.strip() for cell in cells]
                        if len(row) == len(headers):
                            rows.append(row)

                if headers and rows:
                    table_data[table_name] = pd.DataFrame(rows, columns=headers)

            return {
                "Company Name": company_name,
                "Key Metrics": key_metrics,
                "Tables": table_data
            }

        except requests.exceptions.RequestException as e:
            st.error(f"Error fetching Screener.in data: {e}")
            return None

    def analyze(self):
        """Perform complete analysis using both data sources"""
        yahoo_data = self.get_yahoo_data()
        screener_data = self.get_screener_data()

        return {
            "yahoo_finance_data": yahoo_data,
            "screener_data": screener_data
        }

def plot_stock_chart(historical_data):
    """Create a plotly chart for stock price and moving averages"""
    fig = go.Figure()

    # Add candlestick chart
    fig.add_trace(go.Candlestick(
        x=historical_data.index,
        open=historical_data['Open'],
        high=historical_data['High'],
        low=historical_data['Low'],
        close=historical_data['Close'],
        name='Price'
    ))

    # Add moving averages
    fig.add_trace(go.Scatter(
        x=historical_data.index,
        y=historical_data['MA50'],
        name='50-Day MA',
        line=dict(color='blue', width=1.5)
    ))

    fig.add_trace(go.Scatter(
        x=historical_data.index,
        y=historical_data['MA200'],
        name='200-Day MA',
        line=dict(color='red', width=1.5)
    ))

    fig.update_layout(
        title='Stock Price with Moving Averages',
        xaxis_title='Date',
        yaxis_title='Price (₹)',
        height=600,
        xaxis_rangeslider_visible=False
    )

    return fig
    
def format_data_for_llm(analysis_results):
    """Format the analysis results for LLM consumption"""
    formatted_data = ""

    yf_data = analysis_results.get("yahoo_finance_data")
    if yf_data:
        formatted_data += "\nYahoo Finance Data:\n"
        formatted_data += str(yf_data["historical_data"].tail())
        formatted_data += "\n\nFinancials:\n"
        formatted_data += str(yf_data["financials"])

    screener_data = analysis_results.get("screener_data")
    if screener_data:
        formatted_data += "\n\nScreener.in Data:\n"
        formatted_data += f"\nCompany Name: {screener_data['Company Name']}\n"
        formatted_data += "\nKey Metrics:\n"
        for key, value in screener_data["Key Metrics"].items():
            formatted_data += f"{key}: {value}\n"

    return formatted_data

def format_user_profile(profile):
    """Format user financial profile for LLM query"""
    return f"""
    Name: {profile.get('name', 'Not provided')}
    Age: {profile.get('age', 'Not provided')}
    Profession: {profile.get('profession', 'Not provided')}
    Monthly Income: ₹{profile.get('monthly_income', 'Not provided')}
    Monthly Expenses: ₹{profile.get('monthly_expenses', 'Not provided')}
    Risk Tolerance: {profile.get('risk_tolerance', 'Not provided')}
    Investment Horizon: {profile.get('investment_horizon', 'Not provided')} years
    Investment Goal: {profile.get('investment_goal', 'Not provided')}
    """

# MAIN APP
def main():
    # Load data
    df = load_data()
    if st.session_state.all_funds is None:
        st.session_state.all_funds = df
    
    # Create main navigation
    st.sidebar.image("https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500", use_container_width=True)
    st.sidebar.title("Investment Advisor")
    
    # Create navigation menu with Tax Planning added
    menu = st.sidebar.radio(
        "Navigation",
        ["Home", "User Profile", "Explore Funds", "Fund Recommendations", "Portfolio Optimization", "Stock Analysis", "Tax Planning"],
        index=0
    )
    
    # Display page based on selection
    if menu == "Home":
        home_page()
    elif menu == "User Profile":
        user_profile_page()
    elif menu == "Explore Funds":
        explore_funds_page(df)
    elif menu == "Fund Recommendations":
        fund_recommendations_page(df)
    elif menu == "Portfolio Optimization":
        portfolio_optimization_page()
    elif menu == "Stock Analysis":
        stock_analysis_page()
    elif menu == "Tax Planning":
        # Initialize tax planning UI if it doesn't exist yet
        if 'tax_planning_ui' not in st.session_state:
            st.session_state.tax_planning_ui = TaxPlanningUI()
        tax_planning_page(df)

def home_page():
    st.title("Welcome to Investment Advisor")
    st.write("Your comprehensive platform for mutual fund recommendations, stock analysis and tax planning")
    
    # Create a card-like layout
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div style="padding: 20px; border-radius: 10px; border: 1px solid #ddd; height: 200px;">
            <h3>User Profile</h3>
            <p>Create and save your investment profile to get personalized recommendations.</p>
            <br/>
        </div>
        """, unsafe_allow_html=True)
        
    with col2:
        st.markdown("""
        <div style="padding: 20px; border-radius: 10px; border: 1px solid #ddd; height: 200px;">
            <h3>Fund Recommendations</h3>
            <p>Get AI-powered fund recommendations based on your risk tolerance, age, and financial goals.</p>
            <br/>
        </div>
        """, unsafe_allow_html=True)
        
    with col3:
        st.markdown("""
        <div style="padding: 20px; border-radius: 10px; border: 1px solid #ddd; height: 200px;">
            <h3>Tax Planning</h3>
            <p>Optimize your investments for tax efficiency with capital gains calculation and ELSS recommendations.</p>
            <br/>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Features section
    st.header("Key Features")
    features_col1, features_col2 = st.columns(2)
    
    with features_col1:
        st.markdown("#### Mutual Fund Recommendations")
        st.markdown("""
        - Personalized fund selection based on your risk profile
        - Advanced KNN and Random Forest algorithms
        - Special focus on age-appropriate investments
        - SIP amount suggestions based on your income and expenses
        """)
        
    with features_col2:
        st.markdown("#### Portfolio Optimization")
        st.markdown("""
        - AI-powered allocation strategy
        - Risk-return optimization
        - Custom allocation based on your investment goals
        - Visual portfolio comparisons and analysis
        """)
    
    # How to use section
    st.header("How to Use")
    st.markdown("""
    1. Start by creating your **User Profile** with your financial details and goals
    2. Explore available mutual funds in the **Explore Funds** section
    3. Get personalized recommendations in the **Fund Recommendations** section
    4. Optimize your portfolio allocation with our **Portfolio Optimization** tool
    5. Analyze individual stocks with our **Stock Analysis** feature
    """)

def user_profile_page():
    st.title("Create Your Investor Profile")
    st.write("Set up your personal financial profile to get tailored investment recommendations")
    
    # Check if profile exists
    profile_exists = st.session_state.user_profile is not None
    
    # Create tabs for profile management
    profile_tab, saved_profile_tab = st.tabs(["Create/Edit Profile", "Saved Profile"])
    
    with profile_tab:
        # Create form layout
        with st.form("user_profile_form"):
            st.subheader("Personal Information")
            col1, col2 = st.columns(2)
            
            with col1:
                name = st.text_input(
                    "Name", 
                    value=st.session_state.user_profile.get("name", "") if profile_exists else "",
                    placeholder="Enter your name"
                )
                age = st.number_input(
                    "Age", 
                    min_value=18, 
                    max_value=100, 
                    value=st.session_state.user_profile.get("age", 30) if profile_exists else 30
                )
                profession = st.selectbox(
                    "Profession",
                    [
                        "Salaried - Private",
                        "Salaried - Government",
                        "Business Owner",
                        "Freelancer",
                        "Student",
                        "Retired",
                        "Other"
                    ],
                    index=[
                        "Salaried - Private",
                        "Salaried - Government",
                        "Business Owner",
                        "Freelancer",
                        "Student",
                        "Retired",
                        "Other"
                    ].index(st.session_state.user_profile.get("profession", "Salaried - Private")) if profile_exists else 0
                )
            
            with col2:
                monthly_income = st.number_input(
                    "Monthly Income (₹)", 
                    min_value=0, 
                    value=st.session_state.user_profile.get("monthly_income", 50000) if profile_exists else 50000, 
                    step=5000
                )
                monthly_expenses = st.number_input(
                    "Monthly Expenses (₹)", 
                    min_value=0, 
                    value=st.session_state.user_profile.get("monthly_expenses", 30000) if profile_exists else 30000, 
                    step=5000
                )
            
            st.markdown("---")
            st.subheader("Investment Preferences")
            
            col3, col4 = st.columns(2)
            
            with col3:
                risk_tolerance = st.select_slider(
                    "Risk Tolerance",
                    options=["Very Low", "Low", "Moderate", "High", "Very High"],
                    value=st.session_state.user_profile.get("risk_tolerance", "Moderate") if profile_exists else "Moderate"
                )
                
                investment_horizon = st.slider(
                    "Investment Horizon (years)",
                    min_value=1,
                    max_value=30,
                    value=st.session_state.user_profile.get("investment_horizon", 5) if profile_exists else 5
                )
            
            with col4:
                investment_goal = st.selectbox(
                    "Investment Goal",
                    [
                        "Retirement",
                        "House Purchase",
                        "Children's Education",
                        "Marriage",
                        "Vacation",
                        "Wealth Creation",
                        "Tax Saving",
                        "Other"
                    ],
                    index=[
                        "Retirement",
                        "House Purchase",
                        "Children's Education",
                        "Marriage",
                        "Vacation",
                        "Wealth Creation",
                        "Tax Saving",
                        "Other"
                    ].index(st.session_state.user_profile.get("investment_goal", "Wealth Creation")) if profile_exists else 5
                )
                
                existing_investments = st.multiselect(
                    "Existing Investments",
                    [
                        "Fixed Deposits",
                        "Equity Mutual Funds",
                        "Debt Mutual Funds",
                        "Direct Equity",
                        "Real Estate",
                        "Gold",
                        "PPF/EPF",
                        "None"
                    ],
                    default=st.session_state.user_profile.get("existing_investments", []) if profile_exists else []
                )
            
            st.markdown("---")
            st.subheader("Investment Type")
            
            investment_type = st.radio(
                "Investment Type", 
                ["SIP", "Lumpsum"],
                index=0 if not profile_exists or st.session_state.user_profile.get("investment_type") == "SIP" else 1
            )
            
            if investment_type == "SIP":
                col5, col6 = st.columns(2)
                
                with col5:
                    sip_frequency = st.selectbox(
                        "SIP Frequency",
                        ["Monthly", "Quarterly", "Semi-Annually", "Annually"],
                        index=["Monthly", "Quarterly", "Semi-Annually", "Annually"].index(
                            st.session_state.user_profile.get("sip_frequency", "Monthly")
                        ) if profile_exists and st.session_state.user_profile.get("sip_frequency") else 0
                    )
                
                with col6:
                    st.info("Our AI will recommend a suitable SIP amount based on your profile")
            else:
                lumpsum_amount = st.number_input(
                    "Lumpsum Amount (₹)", 
                    min_value=1000, 
                    value=st.session_state.user_profile.get("lumpsum_amount", 100000) if profile_exists and st.session_state.user_profile.get("lumpsum_amount") else 100000, 
                    step=10000
                )
            
            submit_button = st.form_submit_button("Save Profile", type="primary", use_container_width=True)
            
            if submit_button:
                # Save user profile to session state
                st.session_state.user_profile = {
                    "name": name,
                    "age": age,
                    "profession": profession,
                    "monthly_income": monthly_income,
                    "monthly_expenses": monthly_expenses,
                    "risk_tolerance": risk_tolerance,
                    "investment_horizon": investment_horizon,
                    "investment_goal": investment_goal,
                    "existing_investments": existing_investments,
                    "investment_type": investment_type,
                    "sip_frequency": sip_frequency if investment_type == "SIP" else None,
                    "lumpsum_amount": lumpsum_amount if investment_type == "Lumpsum" else None
                }
                st.success("Your profile has been saved successfully! You can now get personalized recommendations.")
    
    with saved_profile_tab:
        if profile_exists:
            st.subheader(f"Profile for {st.session_state.user_profile['name']}")
            
            # Display profile in a nice format
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("#### Personal Information")
                st.markdown(f"**Name:** {st.session_state.user_profile['name']}")
                st.markdown(f"**Age:** {st.session_state.user_profile['age']} years")
                st.markdown(f"**Profession:** {st.session_state.user_profile['profession']}")
            
            with col2:
                st.markdown("#### Financial Details")
                st.markdown(f"**Monthly Income:** ₹{st.session_state.user_profile['monthly_income']:,}")
                st.markdown(f"**Monthly Expenses:** ₹{st.session_state.user_profile['monthly_expenses']:,}")
                st.markdown(f"**Savings Rate:** {((st.session_state.user_profile['monthly_income'] - st.session_state.user_profile['monthly_expenses']) / st.session_state.user_profile['monthly_income'] * 100):.1f}%")
            
            with col3:
                st.markdown("#### Investment Profile")
                st.markdown(f"**Risk Tolerance:** {st.session_state.user_profile['risk_tolerance']}")
                st.markdown(f"**Investment Horizon:** {st.session_state.user_profile['investment_horizon']} years")
                st.markdown(f"**Primary Goal:** {st.session_state.user_profile['investment_goal']}")
            
            st.markdown("---")
            
            col4, col5 = st.columns(2)
            
            with col4:
                st.markdown("#### Investment Type")
                st.markdown(f"**Preferred Type:** {st.session_state.user_profile['investment_type']}")
                
                if st.session_state.user_profile['investment_type'] == "SIP":
                    st.markdown(f"**SIP Frequency:** {st.session_state.user_profile['sip_frequency']}")
                else:
                    st.markdown(f"**Lumpsum Amount:** ₹{st.session_state.user_profile['lumpsum_amount']:,}")
            
            with col5:
                st.markdown("#### Existing Investments")
                if st.session_state.user_profile['existing_investments']:
                    for investment in st.session_state.user_profile['existing_investments']:
                        st.markdown(f"- {investment}")
                else:
                    st.markdown("No existing investments")
        else:
            st.info("No profile has been saved yet. Please create your profile in the 'Create/Edit Profile' tab.")

def tax_planning_page(df):
    """Tax planning page that uses the TaxPlanningUI to render tax planning features"""
    st.session_state.tax_planning_ui.render_tax_planning_section(df)

def explore_funds_page(df):
    st.title("Explore Mutual Funds")
    st.write("Browse all available mutual funds and filter by various criteria")
    
    # Create filter sidebar
    with st.expander("Filter Options", expanded=True):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # Category filter
            categories = ["All"] + sorted(df["category"].unique().tolist())
            selected_category = st.selectbox("Category", categories)
            
            # Risk level filter
            risk_levels = ["All"] + sorted([str(i) for i in range(1, 7)])
            selected_risk = st.selectbox("Risk Level", risk_levels)
        
        with col2:
            # AMC filter
            amcs = ["All"] + sorted(df["amc_name"].unique().tolist())
            selected_amc = st.selectbox("AMC", amcs)
            
            # Rating filter
            ratings = ["All"] + sorted([str(i) for i in range(1, 6)])
            selected_rating = st.selectbox("Rating", ratings)
        
        with col3:
            # Return period filter
            return_periods = ["1 Year", "3 Years", "5 Years"]
            selected_return_period = st.selectbox("Return Period", return_periods)
            
            # Min investment filter
            min_investment = st.slider("Max Min-SIP Amount (₹)", 0, 10000, 5000, step=500)
    
    # Apply filters
    filtered_df = df.copy()
    
    if selected_category != "All":
        filtered_df = filtered_df[filtered_df["category"] == selected_category]
    
    if selected_risk != "All":
        filtered_df = filtered_df[filtered_df["risk_level"] == int(selected_risk)]
    
    if selected_amc != "All":
        filtered_df = filtered_df[filtered_df["amc_name"] == selected_amc]
    
    if selected_rating != "All":
        filtered_df = filtered_df[filtered_df["rating"] == int(selected_rating)]
    
    filtered_df = filtered_df[filtered_df["min_sip"] <= min_investment]
    
    # Sort based on selected return period
    if selected_return_period == "1 Year":
        filtered_df = filtered_df.sort_values("returns_1yr", ascending=False)
    elif selected_return_period == "3 Years":
        filtered_df = filtered_df.sort_values("returns_3yr", ascending=False)
    else:
        filtered_df = filtered_df.sort_values("returns_5yr", ascending=False)
    
    # Display results
    st.markdown(f"### Found {len(filtered_df)} Mutual Funds")
    
    # Create display tabs
    display_tab1, display_tab2 = st.tabs(["Table View", "Performance Charts"])
    
    with display_tab1:
        # Display as table
        display_cols = [
            "scheme_name", "amc_name", "category", "sub_category", 
            "risk_level", "rating", "expense_ratio", "min_sip", "min_lumpsum",
            "returns_1yr", "returns_3yr", "returns_5yr", "sharpe"
        ]
        
        st.dataframe(
            filtered_df[display_cols].reset_index(drop=True),
            use_container_width=True,
            column_config={
                "scheme_name": "Fund Name",
                "amc_name": "AMC",
                "category": "Category",
                "sub_category": "Sub-Category",
                "risk_level": st.column_config.NumberColumn("Risk (1-6)", format="%d"),
                "rating": st.column_config.NumberColumn("Rating (1-5)", format="%d"),
                "expense_ratio": st.column_config.NumberColumn("Expense Ratio (%)", format="%.2f"),
                "min_sip": st.column_config.NumberColumn("Min SIP (₹)", format="₹%d"),
                "min_lumpsum": st.column_config.NumberColumn("Min Lumpsum (₹)", format="₹%d"),
                "returns_1yr": st.column_config.NumberColumn("1Y Return (%)", format="%.2f%%"),
                "returns_3yr": st.column_config.NumberColumn("3Y Return (%)", format="%.2f%%"),
                "returns_5yr": st.column_config.NumberColumn("5Y Return (%)", format="%.2f%%"),
                "sharpe": st.column_config.NumberColumn("Sharpe Ratio", format="%.2f")
            }
        )
    
    with display_tab2:
        if len(filtered_df) > 0:
            # Show top funds performance
            st.subheader(f"Top 10 Funds by {selected_return_period} Returns")
            
            # Prepare data for chart
            top_10_funds = filtered_df.head(10).copy()
            
            # Create chart based on selected return period
            if selected_return_period == "1 Year":
                return_col = "returns_1yr"
                title = "1 Year Returns (%)"
            elif selected_return_period == "3 Years":
                return_col = "returns_3yr"
                title = "3 Year Returns (%)"
            else:
                return_col = "returns_5yr"
                title = "5 Year Returns (%)"
            
            fig = px.bar(
                top_10_funds,
                x="scheme_name",
                y=return_col,
                color="category",
                title=f"Top 10 Funds by {title}",
                labels={"scheme_name": "Fund", return_col: title}
            )
            
            fig.update_layout(height=500)
            st.plotly_chart(fig, use_container_width=True)
            
            # Risk vs Return scatter plot
            st.subheader("Risk vs Return Analysis")
            
            scatter_fig = px.scatter(
                filtered_df,
                x="sd",
                y=return_col,
                color="category",
                size="fund_size_cr",
                hover_name="scheme_name",
                labels={
                    "sd": "Risk (Standard Deviation)",
                    return_col: title,
                    "fund_size_cr": "Fund Size (Cr)"
                }
            )
            
            scatter_fig.update_layout(height=500)
            st.plotly_chart(scatter_fig, use_container_width=True)
        else:
            st.info("No funds match your filter criteria.")

def fund_recommendations_page(df):
    st.title("Fund Recommendations")
    
    # Check if profile exists
    if st.session_state.user_profile is None:
        st.warning("You need to create a user profile first to get personalized recommendations")
        st.button("Create Profile", on_click=lambda: st.sidebar.radio("Navigation", ["Home", "User Profile", "Explore Funds", "Fund Recommendations", "Portfolio Optimization", "Stock Analysis"], index=1))
        return
    
    # Display profile summary
    user_profile = st.session_state.user_profile
    st.subheader(f"Investment Profile for {user_profile['name']}")
    
    profile_col1, profile_col2, profile_col3 = st.columns(3)
    with profile_col1:
        st.metric("Age", f"{user_profile['age']} years")
        st.metric("Monthly Income", f"₹{user_profile['monthly_income']:,}")
    with profile_col2:
        st.metric("Risk Tolerance", user_profile['risk_tolerance'])
        st.metric("Investment Horizon", f"{user_profile['investment_horizon']} years")
    with profile_col3:
        st.metric("Investment Goal", user_profile['investment_goal'])
        st.metric("Investment Type", user_profile['investment_type'])
    
    # Generate recommendations button
    if 'recommended_funds' not in st.session_state or st.session_state.recommended_funds is None:
        if st.button("Generate Recommendations", type="primary"):
            with st.spinner("Analyzing your profile and finding the best mutual funds..."):
                # Generate recommendations
                risk_mapping = {
                    "Very Low": 1,
                    "Low": 2,
                    "Moderate": 3, 
                    "High": 5,
                    "Very High": 6
                }
                
                user_risk_level = risk_mapping[user_profile['risk_tolerance']]
                recommended_funds = recommend_funds(
                    df, 
                    user_risk_level, 
                    user_profile['investment_horizon'], 
                    user_profile['investment_goal'], 
                    user_profile['investment_type'], 
                    user_profile['age']
                )
                
                st.session_state.recommended_funds = recommended_funds
                
                # Get SIP recommendation if applicable
                if user_profile['investment_type'] == "SIP":
                    with st.spinner("Calculating optimal SIP amount..."):
                        sip_recommendation = get_sip_recommendation(
                            user_profile['age'], 
                            user_profile['profession'], 
                            user_profile['monthly_income'], 
                            user_profile['monthly_expenses'], 
                            user_profile['risk_tolerance'], 
                            user_profile['investment_horizon'], 
                            user_profile['investment_goal']
                        )
                        st.session_state.sip_recommendation = sip_recommendation
                
                st.rerun()
    else:
        # Display recommendations
        st.header("Your Personalized Fund Recommendations")
        
        # Get investment recommendations
        recommended_funds = st.session_state.recommended_funds
        
        # Display SIP recommendation if applicable
        if user_profile['investment_type'] == "SIP" and 'sip_recommendation' in st.session_state:
            sip_rec = st.session_state.sip_recommendation
            st.success(f"**Recommended Monthly SIP:** ₹{sip_rec['amount']:,}")
            
            with st.expander("Why this SIP amount?"):
                st.write(sip_rec['reasoning'])
        
        # Create tabs for each recommended fund
        fund_tabs = st.tabs([fund['scheme_name'][:25] + "..." for fund in recommended_funds])
        
        for i, fund_tab in enumerate(fund_tabs):
            with fund_tab:
                fund = recommended_funds[i]
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    # Fund details
                    st.subheader(fund['scheme_name'])
                    st.markdown(f"**AMC:** {fund['amc_name']}")
                    st.markdown(f"**Category:** {fund['category']} - {fund['sub_category']}")
                    
                    # Key metrics
                    metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
                    
                    with metrics_col1:
                        st.metric("Risk Level", f"{fund['risk_level']}/6")
                        st.metric("Min SIP", f"₹{fund['min_sip']}")
                    
                    with metrics_col2:
                        st.metric("Expense Ratio", f"{fund['expense_ratio']}%")
                        st.metric("Min Lumpsum", f"₹{fund['min_lumpsum']}")
                    
                    with metrics_col3:
                        st.metric("Fund Size", f"₹{fund['fund_size_cr']} Cr")
                        st.metric("Fund Age", f"{fund['fund_age_yr']} years")
                    
                    with metrics_col4:
                        st.metric("Rating", f"{fund['rating']}/5")
                        st.metric("Sharpe Ratio", fund['sharpe'])
                
                with col2:
                    # Performance chart
                    st.subheader("Fund Performance")
                    plot_fund_performance(fund)
                    
                    # Risk-return metrics
                    st.markdown("**Risk/Return Metrics**")
                    st.markdown(f"Alpha: {fund['alpha']}")
                    st.markdown(f"Beta: {fund['beta']}")
                    st.markdown(f"Standard Deviation: {fund['sd']}")
                    st.markdown(f"Sortino Ratio: {fund['sortino']}")
        
        # Create a comparison of all recommended funds
        st.subheader("Fund Comparison")
        comparison_tab1, comparison_tab2 = st.tabs(["Performance Comparison", "Risk-Return Analysis"])
        
        with comparison_tab1:
            create_comparison_chart(recommended_funds)
        
        with comparison_tab2:
            create_risk_return_scatter(recommended_funds)
        
        # Option to reset recommendations
        reset_col1, reset_col2, reset_col3 = st.columns([1, 1, 1])
        
        with reset_col1:
            if st.button("Reset Recommendations", use_container_width=True):
                st.session_state.recommended_funds = None
                st.session_state.show_optimization = False
                st.session_state.portfolio_optimization = None
                st.rerun()
        
        with reset_col3:
            if st.button("Optimize Portfolio", type="primary", use_container_width=True):
                st.session_state.show_optimization = True
                st.rerun()

def portfolio_optimization_page():
    st.title("Portfolio Optimization")
    
    # Check if profile and recommendations exist
    if st.session_state.user_profile is None:
        st.warning("You need to create a user profile first")
        return
    
    if st.session_state.recommended_funds is None:
        st.warning("You need to get fund recommendations first")
        return
    
    # Get profile and recommendations
    user_profile = st.session_state.user_profile
    recommended_funds = st.session_state.recommended_funds
    
    # Show optimization results if available, or generate them
    if st.session_state.show_optimization and st.session_state.portfolio_optimization is None:
        with st.spinner("Optimizing your portfolio for maximum returns..."):
            optimization_result = get_portfolio_optimization(
                recommended_funds,
                user_profile['risk_tolerance'],
                user_profile['investment_horizon'],
                user_profile['investment_goal']
            )
            st.session_state.portfolio_optimization = optimization_result
            st.rerun()
    
    if st.session_state.portfolio_optimization is not None:
        # Show optimization results
        optimization = st.session_state.portfolio_optimization
        
        # Create tabs for different sections
        opt_tab1, opt_tab2, opt_tab3 = st.tabs([
            "Portfolio Allocation", 
            "Performance Comparison", 
            "Investment Growth"
        ])
        
        with opt_tab1:
            st.header("Recommended Portfolio Allocation")
            
            # Display allocation
            col1, col2 = st.columns([1, 1])
            
            with col1:
                # Create a table for allocation
                fund_names = [fund['scheme_name'][:25] + "..." for fund in recommended_funds]
                allocations = optimization['allocation']
                
                # Create a DataFrame for the table
                allocation_df = pd.DataFrame({
                    'Fund': fund_names,
                    'Allocation (%)': allocations
                })
                
                st.dataframe(
                    allocation_df, 
                    use_container_width=True,
                    column_config={
                        "Fund": "Fund Name",
                        "Allocation (%)": st.column_config.NumberColumn(
                            "Allocation (%)", 
                            format="%d%%"
                        )
                    }
                )
                
                # Display metrics
                metrics_col1, metrics_col2 = st.columns(2)
                
                with metrics_col1:
                    st.metric("Expected Annual Return", f"{optimization['expected_return']}%")
                    st.metric("Investment Horizon", f"{user_profile['investment_horizon']} years")
                
                with metrics_col2:
                    st.metric("Risk Level", user_profile['risk_tolerance'])
                    if user_profile['investment_type'] == "SIP" and 'sip_recommendation' in st.session_state:
                        st.metric("Monthly SIP", f"₹{st.session_state.sip_recommendation['amount']:,}")
                    else:
                        st.metric("Lumpsum Amount", f"₹{user_profile['lumpsum_amount']:,}")
            
            with col2:
                # Create pie chart
                fig = px.pie(
                    allocation_df, 
                    values='Allocation (%)', 
                    names='Fund',
                    title='Portfolio Allocation',
                    color_discrete_sequence=px.colors.qualitative.Set2
                )
                fig.update_traces(textposition='inside', textinfo='percent+label')
                st.plotly_chart(fig, use_container_width=True)
            
            # Display explanation
            st.subheader("Portfolio Strategy Explanation")
            st.write(optimization['explanation'])
        
        with opt_tab2:
            # Compare equal allocation vs optimized
            st.header("Performance Comparison")
            
            # Prepare data for comparison
            equal_allocation = [20, 20, 20, 20, 20]  # Equal weight
            optimized_allocation = optimization['allocation']
            
            # Calculate expected returns
            equal_expected_return = sum(
                fund['returns_3yr'] * weight / 100 
                for fund, weight in zip(recommended_funds, equal_allocation)
            )
            
            optimized_expected_return = sum(
                fund['returns_3yr'] * weight / 100 
                for fund, weight in zip(recommended_funds, optimized_allocation)
            )
            
            # Create comparison
            comparison_data = pd.DataFrame({
                'Allocation Strategy': ['Equal Weight', 'Optimized'],
                'Expected Annual Return (%)': [equal_expected_return, optimized_expected_return]
            })
            
            # Create bar chart
            fig = px.bar(
                comparison_data,
                x='Allocation Strategy',
                y='Expected Annual Return (%)',
                color='Allocation Strategy',
                title='Expected Returns: Equal Weight vs. Optimized Allocation',
                text_auto='.2f'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Display improvement percentage
            improvement = ((optimized_expected_return - equal_expected_return) / equal_expected_return) * 100
            st.success(f"The optimized portfolio is expected to yield **{improvement:.2f}%** better returns than an equal-weight allocation.")
        
        with opt_tab3:
            # Show projected growth
            st.header("Projected Investment Growth")
            
            # Calculate investment value based on user profile
            if user_profile['investment_type'] == "SIP" and 'sip_recommendation' in st.session_state:
                monthly_investment = st.session_state.sip_recommendation['amount']
                investment_period = user_profile['investment_horizon'] * 12  # months
                
                # Function to calculate SIP growth
                def calculate_sip_growth(monthly_amount, tenure_months, annual_return_percent):
                    r = annual_return_percent / 100 / 12  # monthly rate
                    return monthly_amount * ((pow(1 + r, tenure_months) - 1) / r) * (1 + r)
                
                # Calculate for equal weight and optimized
                equal_final_value = calculate_sip_growth(
                    monthly_investment, 
                    investment_period, 
                    equal_expected_return
                )
                
                optimized_final_value = calculate_sip_growth(
                    monthly_investment, 
                    investment_period, 
                    optimized_expected_return
                )
                
                total_investment = monthly_investment * investment_period
                
                # Create data for plotting
                years = list(range(1, user_profile['investment_horizon'] + 1))
                equal_values = [calculate_sip_growth(monthly_investment, yr * 12, equal_expected_return) for yr in years]
                optimized_values = [calculate_sip_growth(monthly_investment, yr * 12, optimized_expected_return) for yr in years]
                investments = [monthly_investment * yr * 12 for yr in years]
                
                # Create plot data
                plot_data = pd.DataFrame({
                    'Year': years,
                    'Equal Weight': equal_values,
                    'Optimized': optimized_values,
                    'Total Investment': investments
                })
                
                # Create line chart
                fig = px.line(
                    plot_data, 
                    x='Year', 
                    y=['Equal Weight', 'Optimized', 'Total Investment'],
                    title='Projected SIP Growth Over Time',
                    labels={'value': 'Value (₹)', 'variable': 'Strategy'}
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Show final values
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Total Investment", f"₹{total_investment:,.2f}")
                
                with col2:
                    equal_return = equal_final_value - total_investment
                    st.metric(
                        "Equal Weight Returns", 
                        f"₹{equal_return:,.2f}", 
                        f"{(equal_return/total_investment)*100:.2f}%"
                    )
                
                with col3:
                    optimized_return = optimized_final_value - total_investment
                    st.metric(
                        "Optimized Returns", 
                        f"₹{optimized_return:,.2f}", 
                        f"{(optimized_return/total_investment)*100:.2f}%"
                    )
                
                # Show extra returns
                extra_returns = optimized_final_value - equal_final_value
                st.success(f"By using the optimized allocation, you could potentially earn an extra **₹{extra_returns:,.2f}** over {user_profile['investment_horizon']} years.")
            
            else:
                # For lumpsum investments
                lumpsum_amount = user_profile['lumpsum_amount']
                investment_years = user_profile['investment_horizon']
                
                # Calculate compound growth
                equal_final_value = lumpsum_amount * ((1 + equal_expected_return/100) ** investment_years)
                optimized_final_value = lumpsum_amount * ((1 + optimized_expected_return/100) ** investment_years)
                
                # Create data for plotting
                years = list(range(1, investment_years + 1))
                equal_values = [lumpsum_amount * ((1 + equal_expected_return/100) ** yr) for yr in years]
                optimized_values = [lumpsum_amount * ((1 + optimized_expected_return/100) ** yr) for yr in years]
                
                # Create plot data
                plot_data = pd.DataFrame({
                    'Year': years,
                    'Equal Weight': equal_values,
                    'Optimized': optimized_values,
                    'Initial Investment': [lumpsum_amount] * len(years)
                })
                
                # Create line chart
                fig = px.line(
                    plot_data, 
                    x='Year', 
                    y=['Equal Weight', 'Optimized', 'Initial Investment'],
                    title='Projected Lumpsum Growth Over Time',
                    labels={'value': 'Value (₹)', 'variable': 'Strategy'}
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Show final values
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Initial Investment", f"₹{lumpsum_amount:,}")
                
                with col2:
                    equal_return = equal_final_value - lumpsum_amount
                    st.metric(
                        "Equal Weight Final Value", 
                        f"₹{equal_final_value:,.2f}", 
                        f"{((equal_final_value/lumpsum_amount) - 1)*100:.2f}%"
                    )
                
                with col3:
                    optimized_return = optimized_final_value - lumpsum_amount
                    st.metric(
                        "Optimized Final Value", 
                        f"₹{optimized_final_value:,.2f}", 
                        f"{((optimized_final_value/lumpsum_amount) - 1)*100:.2f}%"
                    )
                
                # Show extra returns
                extra_returns = optimized_final_value - equal_final_value
                st.success(f"By using the optimized allocation, you could potentially earn an extra **₹{extra_returns:,.2f}** over {investment_years} years.")
        
        # Investment advice
        st.markdown("---")
        st.subheader("Next Steps")
        st.info("""
        1. Review the recommended allocation and adjust if needed
        2. Consider consulting with a financial advisor before making investment decisions
        3. Start investing regularly and monitor your portfolio performance
        4. Rebalance your portfolio periodically to maintain the recommended allocation
        """)
    else:
        st.info("Generate recommendations first, then click on 'Optimize Portfolio' to see the optimization results.")

def stock_analysis_page():
    st.title("Stock Analysis")
    
    # Check if user profile exists
    if st.session_state.user_profile is None:
        st.warning("Please create your investor profile first to get personalized analysis.")
        st.button("Go to User Profile", on_click=lambda: st.session_state.update({"_current_page": "User Profile"}))
        return

    # Initialize session state variables for the stock analysis page
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    # Stock input form
    with st.form("stock_analysis_form"):
        stock_symbol = st.text_input("Enter Stock Symbol (e.g., RELIANCE, INFY, TCS)", placeholder="Enter NSE symbol")
        col1, col2 = st.columns(2)
        
        with col1:
            period = st.selectbox("Time Period", ["1y", "2y", "5y", "max"], index=0)
        
        with col2:
            st.write("Analysis Options")
            technicals = st.checkbox("Show Technical Indicators", value=True)
            financials = st.checkbox("Show Financial Metrics", value=True)
        
        submit = st.form_submit_button("Analyze Stock", type="primary", use_container_width=True)
    
    if submit and stock_symbol:
        with st.spinner(f"Analyzing {stock_symbol}..."):
            try:
                analyzer = StockAnalyzer(stock_symbol)
                analysis_results = analyzer.analyze()
                st.session_state.stock_analysis_results = analysis_results
                
                # Format data for LLM
                st.session_state.formatted_data = format_data_for_llm(analysis_results)
            except Exception as e:
                st.error(f"Error analyzing stock: {str(e)}")
    
    # Display analysis results
    if 'stock_analysis_results' in st.session_state and st.session_state.stock_analysis_results:
        results = st.session_state.stock_analysis_results
        
        # Show company name
        screener_data = results.get("screener_data")
        if screener_data:
            st.header(screener_data.get("Company Name", stock_symbol))
        
        # Create tabs for different analysis sections
        analysis_tabs = st.tabs(["Price Chart", "Key Metrics", "Financial Data", "AI Investment Analysis"])
        
        with analysis_tabs[0]:
            # Show price chart
            yahoo_data = results.get("yahoo_finance_data")
            if yahoo_data and "historical_data" in yahoo_data:
                st.plotly_chart(plot_stock_chart(yahoo_data["historical_data"]), use_container_width=True)
            else:
                st.warning("No price data available")
        
        with analysis_tabs[1]:
            # Show key metrics
            if screener_data and "Key Metrics" in screener_data:
                st.subheader("Key Financial Metrics")
                
                # Organize metrics in columns
                metrics = screener_data["Key Metrics"]
                cols = st.columns(3)
                
                for i, (key, value) in enumerate(metrics.items()):
                    cols[i % 3].metric(key, value)
            else:
                st.warning("No key metrics available")
        
        with analysis_tabs[2]:
            # Show financial data
            if screener_data and "Tables" in screener_data:
                tables = screener_data["Tables"]
                
                for table_name, table_data in tables.items():
                    st.subheader(table_name)
                    st.dataframe(table_data, use_container_width=True)
            else:
                st.warning("No financial data available")
        
        with analysis_tabs[3]:
            # Add AI investment analysis using Groq
            st.subheader("Investment Suitability Analysis")
            
            if 'formatted_data' in st.session_state and st.session_state.formatted_data:
                user_profile = format_user_profile(st.session_state.user_profile)
                
                # Initialize Groq client
                client = Groq(api_key="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")
                
                # Create the prompt for investment suitability analysis
                suitability_prompt = f"""
                You are a financial advisor. Based on the stock analysis and the investor's financial profile, 
                determine whether this stock aligns with their investment goals. Provide:
                - A summary of whether the stock fits their financial situation
                - Any risks or mismatches to consider
                - An investment recommendation (Buy, Hold, Avoid) 
                - Alternative investment suggestions if applicable
                
                Stock Data:
                {st.session_state.formatted_data}
                
                User Financial Profile:
                {user_profile}
                """
                
                with st.spinner("Generating investment analysis..."):
                    try:
                        # Call Groq API
                        response = client.chat.completions.create(
                            model="llama3-70b-8192",
                            messages=[{"role": "user", "content": suitability_prompt}],
                            temperature=0.1,
                            max_tokens=1024
                        )
                        
                        # Display the analysis
                        st.markdown(response.choices[0].message.content)
                    except Exception as e:
                        st.error(f"Error generating analysis: {e}")
                        st.info("Please ensure you have set up your Groq API key correctly.")
                
                # Add chat interface for personalized questions
                st.markdown("---")
                st.subheader("Ask Personalized Questions")
                st.write("Feel free to ask any specific questions about this stock related to your investment goals:")
                
                # Display chat history
                for q, a in st.session_state.chat_history:
                    st.info(f"**Question:** {q}")
                    st.success(f"**Answer:** {a}")
                
                # Add question input
                user_question = st.text_input("Your question:")
                
                if st.button("Get Answer") and user_question:
                    with st.spinner("Analyzing your question..."):
                        try:
                            # Create the prompt for follow-up questions
                            follow_up_prompt = f"""
                            You are a financial analyst. Using the following stock data and user profile:

                            Stock Data:
                            {st.session_state.formatted_data}
                            
                            User Profile:
                            {user_profile}

                            Please answer this specific question about the stock:
                            {user_question}

                            Provide a clear and concise answer based on the available data. Do not add disclaimers about conducting personal research or consulting financial advisors. Instead, give your direct analysis based on the available data. 
                            At the end, you can mention that this is analysis based on the available data and market conditions may change.
                            """
                            
                            # Call Groq API
                            follow_up_response = client.chat.completions.create(
                                model="llama3-70b-8192",
                                messages=[{"role": "user", "content": follow_up_prompt}],
                                temperature=0.1,
                                max_tokens=1024
                            )
                            
                            answer = follow_up_response.choices[0].message.content
                            
                            # Add to chat history
                            st.session_state.chat_history.append((user_question, answer))
                            
                            # Display the new question and answer
                            st.info(f"**Question:** {user_question}")
                            st.success(f"**Answer:** {answer}")
                            
                            # Clear the input box by rerunning the app
                            st.rerun()
                            
                        except Exception as e:
                            st.error(f"Error generating answer: {e}")
                            st.info("Please ensure you have set up your Groq API key correctly.")
            else:
                st.warning("No data available for AI analysis. Please try analyzing the stock again.")

    # Add disclaimer
    st.sidebar.markdown("---")
    st.sidebar.caption("""
    **Disclaimer:** The investment analysis and recommendations provided are based on historical data and AI analysis. 
    Past performance is not indicative of future results. Always conduct your own research before making investment decisions.
    """)

# Run the app
if __name__ == "__main__":
    main()
