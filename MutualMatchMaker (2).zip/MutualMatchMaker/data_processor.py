import pandas as pd
import numpy as np

def load_and_process_data(file_path):
    """
    Load and preprocess the mutual fund data.
    
    Parameters:
    -----------
    file_path : str
        Path to the CSV file containing mutual fund data
    
    Returns:
    --------
    pandas.DataFrame
        Processed DataFrame ready for use in the recommendation system
    """
    # Load the data
    df = pd.read_csv(file_path)
    
    # Convert percentage strings to float
    for col in ['expense_ratio', 'returns_1yr', 'returns_3yr', 'returns_5yr']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Handle missing values
    # For returns, use median of the same category
    for col in ['returns_1yr', 'returns_3yr', 'returns_5yr']:
        df[col] = df.groupby('category')[col].transform(lambda x: x.fillna(x.median()))
    
    # For other numeric columns, fill with median
    numeric_cols = ['min_sip', 'min_lumpsum', 'expense_ratio', 'fund_size_cr', 
                    'fund_age_yr', 'sortino', 'alpha', 'sd', 'beta', 'sharpe']
    
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
        df[col] = df[col].fillna(df[col].median())
    
    # Fill missing categorical values
    categorical_cols = ['fund_manager', 'amc_name', 'category', 'sub_category']
    for col in categorical_cols:
        df[col] = df[col].fillna('Unknown')
    
    # Convert rating to numeric
    df['rating'] = pd.to_numeric(df['rating'], errors='coerce')
    df['rating'] = df['rating'].fillna(df['rating'].median())
    
    # Create a binary feature for SIP and lumpsum suitability
    df['sip_suitable'] = df['min_sip'] <= 1000
    df['lumpsum_suitable'] = df['min_lumpsum'] <= 10000
    
    # Calculate risk-adjusted returns
    df['risk_adjusted_return_1yr'] = df['returns_1yr'] / df['sd']
    df['risk_adjusted_return_3yr'] = df['returns_3yr'] / df['sd']
    
    # Create a feature for consistency of returns
    # Higher value indicates more consistent returns across different time periods
    df['return_consistency'] = 1 - abs(df['returns_1yr'] - df['returns_3yr']) / (df['returns_1yr'] + df['returns_3yr'] + 1)
    
    # Create a composite score based on multiple factors
    # This can be used as a simple ranking mechanism
    df['composite_score'] = (
        df['rating'] * 0.2 +
        df['sharpe'] * 0.2 +
        df['return_consistency'] * 0.2 +
        (5 - df['expense_ratio']) * 0.1 +  # Lower expense ratio is better
        df['risk_adjusted_return_3yr'] * 0.3
    )
    
    return df
